package main.java.pl.edu.agh.kis.interfaces;

/**
 * Zdefiniowane typy wiadomosci: wiadomosc, dodanie uzytkownika, dodanie pokoju,
 * zaproszenie, informacja o pokoju, wyslanie zaproszenia, wiadomosc prywatna,
 * wylogowanie
 * 
 * @author N.Materek
 * 
 */
public enum Command {
	MESSAGE(0), ADDUSER(1), ADDROOM(2), INVITES(3), INFROOM(4), SENDINVITE(5), PRIVMES(
			6), DISCONNECT(7), DELIVERPRIV(8), SHUTDOWN(9), CHECKROOM(10), THROWING(11);

	private int value;

	private Command(int value) {
		this.value = value;
	}

	/**
	 * Zwraca wartosc int typu wiadomosci
	 * 
	 * @return wartosc wiadomosci
	 */
	public int getValue() {
		return value;
	}
}
