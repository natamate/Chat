package main.java.pl.edu.agh.kis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.management.RuntimeErrorException;

import main.java.pl.edu.agh.kis.interfaces.StoreData;
import main.java.pl.edu.agh.kis.interfaces.UsersDatabase;

import com.sun.corba.se.spi.ior.MakeImmutable;
import com.sun.org.apache.bcel.internal.generic.GETSTATIC;

import sun.font.CreatedFontTracker;
import sun.misc.Cleaner;

/**
 * Klasa przechowujaca dane o wszystkich uzytkownikach czatu allUsers - zbior
 * wszystkich uzytkownikow
 * 
 * @author N.Materek
 * @see StoreData
 * @see Serializable
 * @see Users
 * @see ChatRoom
 * 
 */
public class StoreRooms implements StoreData {

	private static String pathToFile = "Users.txt";

	private static Set<Users> allUsers = Collections
			.synchronizedSet(new HashSet<Users>());

	private static UsersDatabase storage = new DataBaseInFile();

	public StoreRooms() {
		try {
			allUsers = storage.readFromFile();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Usuwa uzytkownika o okreslonym porcie
	 * 
	 * @param localPort
	 *            - port socketa uzytkownika
	 */
	public synchronized void removeUser(int localPort) {
		for (Iterator<Users> it = allUsers.iterator(); it.hasNext();) {
			Users u = it.next();
			if (u.getLocalPort() == localPort) {
				it.remove();
			}
		}
	}

	/**
	 * Zwraca uzytkownika o okreslonym porcie jesli istnieje
	 * 
	 * @param localPort
	 *            - port socketa uzytkownika
	 * @throws NullPointerException kiedy nie znaleziono uzytkownika
	 * @return users uzytkownik o podanym porcie, null w przeciwnym przypadku
	 */
	public synchronized Users getUser(int localPort)
			throws NullPointerException {
		Users tmp = null;

		for (Iterator<Users> it = allUsers.iterator(); it.hasNext();) {
			Users users = it.next();
			if (users.getLocalPort() == localPort) {
				return users;
			}
		}
		return tmp;
	}

	/**
	 * Zwraca zbior wszystkich uzytkownikow
	 * 
	 * @return allUsers zbior wszystkich uzytkownikow
	 */
	public synchronized Set<Users> getSetOfConnectedUsers() {
		return allUsers;
	}

	/**
	 * Ustawia zbior uzytkownikow na podany
	 * 
	 * @param newUsers
	 *            zbior uzytkownikow ktory zostanie zapisany
	 */
	public synchronized void setAllUsersList(Set<Users> newUsers) {
		allUsers = newUsers;
	}

	/**
	 * Dodaje uzytkownika jesli nie istnieje uzytkownik z podanym username w
	 * przeciwnym przypadku aktualizuje port uzytkownika juz istniejacego
	 * 
	 * @param user
	 *            uzytkownik ktory ma zostac dodany lub zaaktualizowany w
	 *            zbiorze wszystkich uzytkownikow
	 */
	public synchronized void addUser(Users user) {
		if (containsUserWithUserName(user.getUserName()) == false) {
			allUsers.add(user);
		} else {
			updateLocalPortExistUser(user);
		}
	}

	/**
	 * Metoda zmienia pokoj uzytkownika z podana nazwa
	 * 
	 * @param userName
	 *            nazwa uzytkownika dla ktorego pokoj ma byc zmieniony
	 * @param newChatRoom
	 *            nowy pokoj uzytkownika
	 */
	public synchronized void changeRoom(String userName, ChatRoom newChatRoom) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users user = i.next();
			if (user.getUserName().equals(userName) == true) {
				user.setRoomName(newChatRoom.getRoomName(),
						newChatRoom.getAvailable());
			}
		}
	}

	/**
	 * sprawdza czy zbior uzytkownikow jest pusty
	 * 
	 * @return true gdy nie ma zadnych uzytkownikow
	 * @return false gdy istnieje uzytkownik
	 */
	public synchronized boolean isEmpty() {
		if (allUsers.isEmpty() == true) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * zwraca aktualny pokoj uzytkownika o podanej nazwie
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return chatRoom aktualny pokoj uzytkownika o podanej nazwie lub pokoj
	 *         domyslny jesli nie ma uzytkownika o podanej nazwie
	 */
	public synchronized ChatRoom getChatRoom(String userName) {
		ChatRoom chatRoom = new ChatRoom(0, "public");
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				chatRoom = new ChatRoom(users.getAvailableRoom(),
						users.getRoomName());
				return chatRoom;
			}
		}
		return chatRoom;
	}

	/**
	 * Sprawdza czy uzytkownik o podanej nazwie juz istnieje
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return true jestli uzytkownik istnieje w zbiorze
	 * @return false w przeciwnym przypadku
	 */
	public synchronized boolean containsUserWithName(String userName) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Sprawdza czy uzytkownik o podanej nazwie i hasle istnieje
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @param password
	 *            haslo uzytkownika
	 * @return true jestli uzytkownik istnieje w zbiorze
	 * @return false w przeciwnym przypadku
	 */
	public synchronized boolean containsUserWithData(String userName,
			String password) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			System.out.println(users.getUserName() + " : "
					+ users.getPassword() + " : " + password);
			if (users.getUserName().equals(userName) == true
					&& users.getPassword().equals(password) == true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * sprawdza czy nazwa pokoju czatu jest juz zajeta
	 * 
	 * @param chatRoomName
	 *            nazwa pokoju
	 * @return true jesli pokoj z podana nazwa juz istnieje
	 * @return false w przeciwnym przypadku
	 */
	public synchronized boolean containsChatRoomName(String chatRoomName) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getRoomName().equals(chatRoomName) == true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Zwraca liste nazw wszystkich uzytkownikow
	 * 
	 * @return nameAllUsers lista wszystkich uzytkownikow
	 */
	public synchronized ArrayList<String> getArrayOfNameAllUsers() {
		ArrayList<String> nameAllUsers = new ArrayList<>();
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users user = i.next();
			if (user.getUserName().equals("root") == true) {
				continue;
			}
			nameAllUsers.add(user.getUserName());
		}
		return nameAllUsers;
	}

	/**
	 * Dodaje wiadomosc do przechowania dla uzytkownika o podanej nazwie
	 * 
	 * @param userName
	 *            nazwa uzytkownika dla ktorego przeznaczona jest wiadomosc
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 * @param messages
	 *            wiadomosci dla uzytkownika
	 */
	public synchronized void addMessagesForUser(String userName,
			String nameSender, String messages) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				users.addMessagesForUser(nameSender, messages);
			}
		}
	}

	/**
	 * Zwraca wiadomosci przechowywane dla uzytkownika z podanym portem lub null
	 * jesli uzytkownik nie posiada wiadomosci
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return messagesForUser wiadomosci ktore uzytkownik otrzymal podczas
	 *         swojej nieobecnosci lub null jesli nie ma wiadomosci dla tego
	 *         uzytkownika
	 */
	public synchronized Map<String, String> getMessagesForUser(String userName)
			throws NullPointerException {
		Map<String, String> messagesForUser = null;
		try {
			for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
				Users users = i.next();
				if (users.getUserName().equals(userName) == true) {
					messagesForUser = users.getMessagesForUser();
				}
			}
			return messagesForUser;
		} catch (NullPointerException e) {
			ChatServer.logs.addError("Nie ma wiadomosci dla uzytkownika: "
					+ userName + " " + e.toString());
		}
		throw new RuntimeException(
				"Nie ma wiadomosci dla uzytkownika o nazwie: " + userName);
	}

	/**
	 * usuwa wiadomosci przechowywane dla uzytkownika o podanym porcie
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @param userNameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 */
	public synchronized void clearMessageForUser(String userName,
			String userNameSender) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				users.clearMessagesForUser(userNameSender);
			}
		}
	}

	/**
	 * Usuwa konkretnego uzytkownika ze zbioru wszystkich uzytkownikow
	 * 
	 * @param user
	 *            uzytkownik ktory ma zostac usuniety
	 */
	public synchronized void removeUser(Users user) {
		for (Iterator<Users> it = allUsers.iterator(); it.hasNext();) {
			Users u = it.next();
			if (u.getUserName().equals(user.getUserName()) == true) {
				it.remove();
				break;
			}
		}
	}

	/**
	 * Zapisuje wszytskich uzytkownikow do pliku
	 */
	public synchronized void saveAllUsers() {
		try {
			storage.writeToFile(allUsers);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Aktualizuje port uzytkownika w zbiorze
	 * 
	 * @param user
	 *            uzytkownik ktorego port bedzie aktualizowany
	 */
	private synchronized void updateLocalPortExistUser(Users user) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(user.getUserName()) == true) {
				users.setLocalPort(user.getLocalPort());
				break;
			}
		}
	}

	/**
	 * Zwraca port socketa uzytkownika o podanej nazwie lub 0 jesli uzytkownik o
	 * podanej nazwie nie istnieje
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return localPort port socketa lub 0 jesli uzytkownik nie istnieje
	 */
	private synchronized int getLocalPort(String userName) {
		int localPort = 0;
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				localPort = users.getLocalPort();
			}
		}
		return localPort;
	}

	/**
	 * Zwraca rozmiar zbioru wszystkich uzytkownikow
	 * 
	 * @return return liczba wszystkich uzytkownikow w zbiorze
	 */
	private synchronized int size() {
		int result = 0;
		for (Iterator<Users> it = allUsers.iterator(); it.hasNext();) {
			Users u = it.next();
			result++;
		}
		return result;
	}

	/**
	 * Sprawdza czy uzytkownik o podanej nazwie istnieje
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return true jest uzytkownik o podanej nazwie istnieje
	 * @return false w przeciwnym przypadku
	 */
	private synchronized boolean containsUserWithUserName(String userName) {
		for (Iterator<Users> i = allUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				return true;
			}
		}
		return false;
	}

}
