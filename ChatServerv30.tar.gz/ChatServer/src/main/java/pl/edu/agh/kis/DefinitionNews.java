package main.java.pl.edu.agh.kis;

import java.util.ArrayList;

import javax.smartcardio.CommandAPDU;

import main.java.pl.edu.agh.kis.interfaces.Command;
import main.java.pl.edu.agh.kis.interfaces.SupportMessages;


public class DefinitionNews implements SupportMessages {
	/**
	 * Wlasciwa tresc wiadomosci
	 */
	private String[] message;
	/**
	 * Zmienna okreslajaca typ wiadomosci: wiadomosc standardowa, zaproszenie,
	 * wiadomosc prywatna
	 */
	private int typeMessage = 0;

	public DefinitionNews() {

	}

	private DefinitionNews(int typeMessage, String[] message) {
		this.typeMessage = typeMessage;
		this.message = message;
	}

	/**
	 * Zwraca wiadomosc z okreslonym typem patrz Command MESSAGE(0), ADDUSER(1),
	 * ADDROOM(2), INVITES(3), INFROOM(4), SENDINVITE(5), PRIVMES( 6),
	 * DISCONNECT(7), DELIVERPRIV(8);
	 */
	public DefinitionNews makeDefinitionNews(String inputMessage) {

		if (inputMessage.contains("#@$!") == false) {
			String[] message = { inputMessage };
			this.message = message;
			return new DefinitionNews(0, message);
		}
		String tmp = inputMessage.substring(15);
		String[] messageData = tmp.split(", ");
		message = messageData;
		return new DefinitionNews(getTypeFromCommand(inputMessage), messageData);
	}

	private int getTypeFromCommand(String inputMessages) {
		if (inputMessages.contains("ADDUSER") == true) {
			typeMessage = Command.ADDUSER.getValue();
			return Command.ADDUSER.getValue();
		} else if (inputMessages.contains("ADDROOM") == true) {
			typeMessage = Command.ADDROOM.getValue();
			return Command.ADDROOM.getValue();
		} else if (inputMessages.contains("INVITES") == true) {
			typeMessage = Command.INVITES.getValue();
			return Command.INVITES.getValue();
		} else if (inputMessages.contains("INFROOM") == true) {
			typeMessage = Command.ADDROOM.getValue();
			return Command.INFROOM.getValue();
		} else if (inputMessages.contains("SENDINVITE") == true) {
			typeMessage = Command.SENDINVITE.getValue();
			return Command.SENDINVITE.getValue();
		} else if (inputMessages.contains("PRIVMES") == true) {
			typeMessage = Command.PRIVMES.getValue();
			return Command.PRIVMES.getValue();
		} else if (inputMessages.contains("DISCONNECT") == true) {
			typeMessage = Command.DISCONNECT.getValue();
			return Command.DISCONNECT.getValue();
		} else if (inputMessages.contains("MESSAGE") == true) {
			typeMessage = Command.DELIVERPRIV.getValue();
			return Command.DELIVERPRIV.getValue();
		}else if(inputMessages.contains("SHUTDOWN") == true){
			typeMessage = Command.SHUTDOWN.getValue();
			return Command.SHUTDOWN.getValue();
		}else if(inputMessages.contains("CHECKROOM") == true){
			typeMessage = Command.CHECKROOM.getValue();
			return Command.CHECKROOM.getValue();
		} else if(inputMessages.contains("THROWING") == true){
			typeMessage = Command.THROWING.getValue();
			return Command.THROWING.getValue();
		} else {
			typeMessage = Command.MESSAGE.getValue();
			return Command.MESSAGE.getValue();
		}
	}

	/**
	 * Zwraca tresc wiadomosci
	 * 
	 * @return wlasciwa tresc
	 */
	public String[] getMessage() {
		return message;
	}

	/**
	 * Zwraca typ wiadomosci
	 * 
	 * @return int typ
	 */
	public int getTypeMessage() {
		return typeMessage;
	}
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("Type: " + typeMessage + "\n");
		for (String s : message){
			sb.append(s + " ");
		}
		return sb.toString();
	}
}
