package main.java.pl.edu.agh.kis;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

import main.java.pl.edu.agh.kis.interfaces.UsersDatabase;

/**
 * Klasa obsluguje zapis i odczyt z pliku uzytkownikow ktorzy juz istnieja.
 * 
 * @author N.Materek
 * 
 */
public class DataBaseInFile implements UsersDatabase {
	private String pathToFile = "src/main/resources/pl/edu/agh/kis/Users.txt";

	public DataBaseInFile() {
		File file = new File(pathToFile);
		try {
			if (!file.exists())
			    file.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	/**
	 * Zapisuje do pliku zbior uzytkownikow
	 * 
	 * @param allUser
	 *            zbior wszytskich uzytkownikow
	 * @throws IOException
	 *             przy bledzie w zapisaniu danych
	 * @throws FileNotFoundException
	 *             gdy nie znaleziono pliku
	 */
	@Override
	public void writeToFile(Set<Users> allUser) throws IOException,
			FileNotFoundException {
		PrintWriter writer = new PrintWriter(pathToFile, "UTF-8");
		for (Users user : allUser) {
			StringBuilder users = new StringBuilder();
			users.append(user.getUserName() + ", ");
			users.append(user.getPassword() + ", ");
			users.append(user.getRoomName() + ", ");
			users.append(user.getAvailableRoom() + ", ");
			Map<String, String> messages = user.getMessagesForUser();
			if (messages != null) {
				for (Map.Entry<String, String> entry : messages.entrySet()) {
					users.append(entry.getValue() + ", " + entry.getKey()
							+ ", ");
				}
			}
			writer.println(users.toString());
		}
		writer.close();
	}

	/**
	 * Odczytuje z pliku zbior juz zapisanych uzytkownikow
	 * 
	 * @throws IOException
	 *             przy bledzie w zapisaniu danych
	 * @throws FileNotFoundException
	 *             gdy nie znaleziono pliku
	 * @return zbior uzytkownikow ktorzy juz istnieja
	 * 
	 */
	@Override
	public Set<Users> readFromFile() throws IOException, FileNotFoundException {
		Set<Users> allUsers = new HashSet<Users>();
		BufferedReader br = new BufferedReader(new FileReader(pathToFile));
		String line = "";
		try {
			line = br.readLine();

			while (line != null) {
				String[] user = line.split(", ");

				Map<String, String> notReceiveMessage = new HashMap<String, String>();

				int j = 0;
				if (user.length > 4) {
					for (int i = 4; i < user.length - 1; i++) {
						j = i + 1;
						notReceiveMessage.put(user[j], user[i]);
						++i;
					}
				}

				allUsers.add(new Users(user[0], user[1], new ChatRoom(user[3],
						user[2]), notReceiveMessage));
				line = br.readLine();
			}

		} finally {
			br.close();
		}
		return allUsers;
	}

	/**
	 * Zwraca aktualna sciezke do pliku
	 * 
	 * @return sciezka
	 */
	@Override
	public String getActualPath() {
		return pathToFile;
	}
	
	/**
	 * Ustawia sciezke do pliku na podana
	 * 
	 * @param newPath
	 *            nowa sciezka do pliku
	 */
	@Override
	public void setPath(String newPath){
		pathToFile = newPath;
	}
}
