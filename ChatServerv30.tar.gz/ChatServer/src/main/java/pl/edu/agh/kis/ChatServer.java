package main.java.pl.edu.agh.kis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.*;
import java.rmi.server.LogStream;
import java.util.*;

import main.java.pl.edu.agh.kis.interfaces.ModificationsConnectedUsers;
import main.java.pl.edu.agh.kis.interfaces.StoreData;
import main.java.pl.edu.agh.kis.interfaces.SupportMessages;

import pl.edu.agh.kis.Logs;
import pl.edu.agh.kis.MiniLog;
import sun.security.action.GetLongAction;

class ChatServer {

	public static ServerSocket server;
	public static StoreData allUsers = new StoreRooms();
	public static ModificationsConnectedUsers connectionUsers = new ConnectionsUsers();

	public static Logs logs = MiniLog
			.getLogsContainer("InfoAboutException.txt");
	public final static int port = 1027;
	public final static String host = "127.0.1.1";

	public static void main(String[] args) throws BindException {
		try {

			server = new ServerSocket(port);

			connectionUsers.switchFlag();

			System.out.println("Waiting for client ...");

			while (connectionUsers.getRunningFlag() == true && server.isClosed() == false) {
				System.out.println(connectionUsers.getRunningFlag());
				System.out.println(connectionUsers.getDisposeFlag());
				
				Socket newUser = server.accept();

				System.out.println("Client connected from: "
							+ newUser.getLocalAddress().getHostName());

				connectionUsers.addUserName(newUser);

				ChatServerThread chat = new ChatServerThread(newUser);

				Thread X = new Thread(chat);
				X.start();

			}
		} catch (SocketException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			System.err.println(e);
			logs.addError("IOException " + e.toString());
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.err.println(e);
			logs.addError("NullPointerException " + e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			System.err.println(e);
			logs.addError("Exception " + e.toString());
			e.printStackTrace();
		}
		finally{
			logs.appendStatementToFile("src/main/resources/pl/edu/agh/kis/ChatServerException.txt");
		}
	}

}