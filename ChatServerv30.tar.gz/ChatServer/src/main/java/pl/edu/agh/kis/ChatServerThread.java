package main.java.pl.edu.agh.kis;

import java.net.*;
import java.sql.Array;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.io.*;

import javax.swing.JOptionPane;

import main.java.pl.edu.agh.kis.interfaces.AppearanceMessages;
import main.java.pl.edu.agh.kis.interfaces.ChatServerThreadUtils;
import main.java.pl.edu.agh.kis.interfaces.SupportMessages;

public class ChatServerThread implements Runnable, ChatServerThreadUtils {

	private Socket socket = null;
	private Scanner input;
	private PrintWriter out;
	private SupportMessages message = new DefinitionNews();

	public ChatServerThread(Socket socket) {
		this.socket = socket;
	}

	public void checkConnection() throws IOException {

		if (socket.isClosed() == true) {
			Set<Users> connectUsers = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Users user : connectUsers) {
				Socket tmpSocket = user.getSocket();
				if (user.getSocket().equals(socket)) {
					System.out.println(tmpSocket.getLocalAddress()
							.getHostName() + " disconnected");
					ChatServer.allUsers.saveAllUsers();
					ChatServer.connectionUsers.removeUser(user);
				}
			}

			ChatServer.connectionUsers.sendNewVisibleList();
		}

		if (ChatServer.connectionUsers.containsUser(socket.getPort()) == false) {
			socket.close();
		}

	}

	/*
	 * Konwertuje ciag znakow do liczby
	 * 
	 * @param number liczba jako ciagu znakow
	 * 
	 * @throw NumberFormatException
	 * 
	 * @return liczba typu int
	 */
	private int convertFromString(String number) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			System.err.println(e);
			e.printStackTrace();
			throw new RuntimeException("Number Format Exception");
		}
	}

	public void updateRoomInArray(String[] receiveMessage) {

		String userName = receiveMessage[0];

		ChatServer.connectionUsers.changeChatRoom(userName, new ChatRoom(
				receiveMessage[2], receiveMessage[1]));
		//System.out.println("Update room in array");
		//ChatServer.connectionUsers.printCurrentUsers();
	}

	public void sendInvite(String[] receiveMessage) throws IOException {

		String nameSender = receiveMessage[0];
		String nameReceiver = receiveMessage[1];
		String nameChatRoom = receiveMessage[2];

		if (ChatServer.connectionUsers.containsUserWithName(nameReceiver) == true) {
			Set<Users> connectedUsers = ChatServer.connectionUsers
					.getAllConnectedUsers();
			for (Users u : connectedUsers) {
				if (u.getUserName().equals(nameReceiver) == true) {
					sendMessageToChoosen(u.getLocalPort(), "Hej "
							+ nameReceiver + "! You invited to room by "
							+ nameSender + "\n");
					ChatRoom tmp = ChatServer.allUsers.getChatRoom(nameSender);
					sendMessageToChoosen(u.getLocalPort(),
							ConnectionsUsers.commandArray[2] + nameSender
									+ ", " + nameReceiver + ", " + nameChatRoom
									+ ", " + tmp.getAvailable());
				}
			}
		} else {
			ChatServer.allUsers.addMessagesForUser(nameReceiver, nameSender,
					"The user: " + nameSender + " send you a invitation");
		}
	}

	public void sendPrivateMessage(String[] receiveMessage) throws IOException {

		String nameSender = receiveMessage[0];
		String nameReceiver = receiveMessage[1];
		String message = receiveMessage[2];

		if (ChatServer.connectionUsers.containsUserWithName(nameReceiver) == true) {
			Set<Users> connectedUsers = ChatServer.connectionUsers
					.getAllConnectedUsers();
			for (Users u : connectedUsers) {
				if (u.getUserName().equals(nameReceiver) == true) {

					sendMessageToChoosen(u.getLocalPort(), "Hej "
							+ nameReceiver + "! The: " + nameSender
							+ " send you a private message : " + "\n" + message
							+ "\n");
					sendMessageToChoosen(u.getLocalPort(),
							ConnectionsUsers.commandArray[7] + nameSender
									+ ", " + nameReceiver + ", " + message
									+ "\n");
				}
			}
		} else {
			ChatServer.allUsers.addMessagesForUser(nameReceiver, nameSender,
					message);
		}
	}

	public void shutDownServer(int portRoot) {
		System.out.println("Root port: " + portRoot);
		if (ChatServer.connectionUsers.checkIfRoot(portRoot) == true) {
			synchronized (ChatServer.connectionUsers) {
				Set<Users> connected = ChatServer.connectionUsers
						.getAllConnectedUsers();
				for (Users u : connected) {
					try {
						
						sendMessageToChoosen(u.getLocalPort(),
								"Server is closed " + "\n");

						sendMessageToChoosen(
								u.getLocalPort(),
								ConnectionsUsers.commandArray[6]
								//ConnectionsUsers.commandArray[11]
										+ u.getLocalPort());

					} catch (IOException e) {
						e.printStackTrace();
					} catch (ConcurrentModificationException e) {
						e.printStackTrace();
					}
				}
				//System.out.println("SHUTDOWN");
				ChatServer.connectionUsers.removeUser("root");

			}
			ChatServer.connectionUsers.switchFlag();
			System.out.println("Flag: " + ChatServer.connectionUsers.getRunningFlag());
		}

	}

	public void checkExistsRoom(String[] data) {
		String userName = data[0];
		String roomName = data[1];
		String available = data[2];

		if (ChatServer.allUsers.containsChatRoomName(roomName) == false) {
			//System.out.println(data[0] + " room is : " + data[1] + " "
			//		+ data[2]);
			updateRoomInArray(data);
			ChatServer.connectionUsers.updateRoomsList();

		} else {
			JOptionPane
					.showMessageDialog(null, "The name of the room is busy.");
		}
	}

	public void sendMessageToCorrectRoom(String message) throws IOException {

		if (ChatServer.connectionUsers.checkIfRoot(socket.getPort()) == true) {
			Set<Users> connectUser = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Iterator<Users> i = connectUser.iterator(); i.hasNext();) {
				Users users = i.next();
				sendMessageToChoosen(users.getLocalPort(), message);
			}
		} else {
			String roomNameSender = ChatServer.connectionUsers
					.getChatRoomName(socket.getPort());

			Set<Users> connectUser = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Iterator<Users> i = connectUser.iterator(); i.hasNext();) {
				Users users = i.next();
				if (users.getRoomName().equals(roomNameSender) == true) {
					sendMessageToChoosen(users.getLocalPort(), message);
				}
			}
		}
	}

	public void run() {
		try {
			try {
				input = new Scanner(socket.getInputStream());
				out = new PrintWriter(socket.getOutputStream());
				while (ChatServer.connectionUsers.getRunningFlag() == true || ChatServer.connectionUsers.getDisposeFlag() == false) {
					try {

						checkConnection();

						//ChatServer.connectionUsers.printCurrentUsers();

						if (input.hasNext() == false
								|| socket.isClosed() == true) {
							return;
						}

						SupportMessages newMessage = message
								.makeDefinitionNews(input.nextLine());

						switch (newMessage.getTypeMessage()) {
						case 0:
							System.out.println(newMessage.getMessage()[0]);
							sendMessageToCorrectRoom(newMessage.getMessage()[0]);
							break;
						case 1:
						case 2:
						case 3:
							break;
						case 4:
							updateRoomInArray(newMessage.getMessage());
							ChatServer.connectionUsers.updateRoomsList();
							break;
						case 5:
							sendInvite(newMessage.getMessage());
							break;
						case 6:
							sendPrivateMessage(newMessage.getMessage());
							break;
						case 7:
							System.out.println("LocalPort to remove: "
									+ newMessage.getMessage()[0]);
							ChatServer.allUsers.saveAllUsers();
							ChatServer.connectionUsers.removeUser(newMessage
									.getMessage()[0]);
							break;
						case 9:

							shutDownServer(convertFromString(newMessage
									.getMessage()[0]));

							return;
						case 10:
							checkExistsRoom(newMessage.getMessage());
							break;
						default:
							break;
						}

						System.out.println("Client said: " + newMessage
								+ " Client's localPort: " + socket.getPort());

					} catch (Exception e) {
						ChatServer.logs.addError("Exception: " + e.toString());
						e.printStackTrace();
						try {
							Thread.sleep(2);
						} catch (InterruptedException f) {
							ChatServer.logs.addError("InterruptedException: "
									+ f.toString());
							f.printStackTrace();
						}
					}

				}
			} catch (SocketException e) {
				e.printStackTrace();
			} finally {

				if (socket != null) {
					socket.close();
				}
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ChatServer.logs
					.appendStatementToFile("src/main/resources/pl/edu/agh/kis/ChatServerException.txt");
			//System.out.println("FINALLYL " + ChatServer.connectionUsers.getRunningFlag() + " dispose: " + ChatServer.connectionUsers.getDisposeFlag());
			//ChatServer.connectionUsers.printCurrentUsers();
			if (ChatServer.connectionUsers.getDisposeFlag() == true) {
				System.out.println("CLOSE");
				ChatServer.allUsers.saveAllUsers();
				try {
					ChatServer.server.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.exit(0);
			}
		}
	}

	/*
	 * Wysyla wiadomosc do uzytkownika w zbiorze polaczonych uzytkownikow o
	 * odpowiednim porcie
	 * 
	 * @param localPort port socketa uzytkownika do ktorego ma byc wyslana
	 * wiadomosc
	 * 
	 * @param message tresc wiadomosci
	 * 
	 * @throws IOException
	 */
	private static void sendMessageToChoosen(int localPort, String message)
			throws IOException {
		try {
			Set<Users> connectUser = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Users user : connectUser) {
				if (user.getLocalPort() == localPort) {
					Socket tmpSocket = user.getSocket();
					PrintWriter tmpOut = new PrintWriter(
							tmpSocket.getOutputStream());
					tmpOut.println(message);
					tmpOut.flush();
					System.out.println("Send to: "
							+ tmpSocket.getLocalAddress().getHostName());
					break;
				}
			}

		} catch (SocketException e) {
			ChatServer.logs.addError("Socket Exception" + e.toString());
			e.printStackTrace();
		}
	}

}