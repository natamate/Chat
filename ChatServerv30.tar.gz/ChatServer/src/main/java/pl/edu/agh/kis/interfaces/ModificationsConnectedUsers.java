package main.java.pl.edu.agh.kis.interfaces;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Set;

import main.java.pl.edu.agh.kis.ChatRoom;
import main.java.pl.edu.agh.kis.Users;

/**
 * Udostepnia zbior metod pozwalajacych na aktualizowanie danych o polaczonych
 * uzytkownikach
 * 
 * @author N.Materek
 * 
 */
public interface ModificationsConnectedUsers {

	/**
	 * Aktualizuje nazwe nowego uzytkownika w zbiorze polaczonych uzytkownikow
	 * 
	 * @param newUser
	 *            socket nowego uzytkownika
	 * @throws IOException
	 *             gdy wystapia problemy z socketem, polaczeniem
	 */
	void addUserName(Socket newUser) throws IOException;

	/**
	 * Wyswietla zbior wszystkich uzytkownikow oraz aktualnie polaczonych
	 */
	void printCurrentUsers();

	/**
	 * Wysyla aktualna liste polaczonych uzytkownikow do polaczonych
	 * uzytkownikow
	 * 
	 * @throws IOException
	 *             gdy wystapia problemy z socketem, polaczeniem
	 */
	void sendNewVisibleList() throws IOException;

	/**
	 * wysyla wiadomosc do polaczonych uzytkownikow o dostepnych pokojach,
	 * dostepne pokoje maja available = 0
	 */
	void updateRoomsList();

	/**
	 * Sprawdza czy polaczony uzytkownik nie ma zaleglych wiadomosci, dodaje
	 * wiadomosci do wyslania jesli istnieja
	 */
	void updateNotReceiverMessages();

	/**
	 * Dodaje uzytkownika
	 * 
	 * @param newUser
	 *            uzytkownik do dodania
	 */
	void addUser(Users newUser);

	/**
	 * Zwraca zbior aktualnie polaczonych uzytkownikow
	 * 
	 * @return zbior polaczonych uzytkownikow
	 */
	Set<Users> getAllConnectedUsers();

	/**
	 * Usuwa podanego uzytkownika
	 * 
	 * @param toRemove
	 *            uzytkownik do usuniecia
	 */
	void removeUser(Users toRemove);

	/**
	 * Usuwa uzytkownika z podana nazwa
	 * 
	 * @param userNameToRemove
	 *            nazwa uzytkownika do usuniecia
	 */
	public void removeUser(String userNameToRemove);

	/**
	 * sprawdza czy jest polaczony uzytkownik z podanym portem
	 * 
	 * @param localPort
	 *            port socketa uzytkownika
	 * @return true jesli uzytkownik jest polaczony
	 * @return false w przeciwnym przypadku
	 */
	boolean containsUser(int localPort);

	/**
	 * sprawdza czy jest polaczony uzytkownik z podana nazwa uzytkownika
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return true jesli uzytkownik jest polaczony
	 * @return false w przeciwnym przypadku
	 */
	boolean containsUserWithName(String userName);

	/**
	 * Zwraca nazwe pokoju w ktorym jest uzytkownik o podanym porcie
	 * 
	 * @param localPort
	 *            port socketa uzytkownika
	 * @return nazwa pokoju w ktorym jest obecnie uzytkownik lub nazwe pokoju
	 *         domyslnego jesli nie ma uzytkownika o podanym porcie
	 */
	String getChatRoomName(int localPort);

	/**
	 * Zmienia pokoj dla podanego uzytkownika
	 * 
	 * @param userName
	 *            naazwa uzytkownika
	 * @param newChatRoom
	 *            nowy pokoj uzytkownika
	 */
	void changeChatRoom(String userName, ChatRoom newChatRoom);

	/**
	 * Zwraca flage okreslajaca czy serwer ma chodzic
	 * 
	 * @return running - true jesli serwer ma chodzic, false w przeciwnym
	 *         przypadku
	 */
	boolean getRunningFlag();

	/**
	 * Zwraca flage okreslajaca czy zostaly oczyszczone wszystkie zasoby
	 * 
	 * @return ifDispose - true jesli oczyszczono juz zasoby, false w przeciwnym
	 *         przypadku
	 */
	boolean getDisposeFlag();
	
	/**
	 * Przestawia wartosc flagi
	 * 
	 */
	void switchFlag();

	/**
	 * Sprawdza czy pod podanym portem polaczony jest root
	 * 
	 * @param localPort
	 *            port socketa roota
	 * @return true jesli pod podanym portem jest polaczony root, false w
	 *         przeciwnym przypadku
	 */
	boolean checkIfRoot(int localPort);
}
