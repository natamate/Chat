package main.java.pl.edu.agh.kis.interfaces;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import main.java.pl.edu.agh.kis.ChatRoom;
import main.java.pl.edu.agh.kis.StoreRooms;
import main.java.pl.edu.agh.kis.Users;
import main.java.pl.edu.agh.kis.ConnectionsUsersContainer;

/**
 * Udostepnia zbior metod pozwalajacych na modfikacje i odczyt danych zawartych we zbiorze uzytkownikow
 * @author N.Materek
 * @see StoreRooms
 * @see ConnectionsUsersContainer
 */
public interface StoreData {	
	/**
	 * Zwraca uzytkownika o okreslonym porcie jesli istnieje
	 * 
	 * @param port
	 *            - port socketa uzytkownika
	 * @throws NullPointerException kiedy nie znaleziono uzytkownika
	 * @return users uzytkownik o podanym porcie, null w przeciwnym przypadku
	 */
	public Users getUser(int port) throws NullPointerException;
		
	/**
	 * Zwraca zbior wszystkich uzytkownikow
	 * 
	 * @return allUsers zbior wszystkich uzytkownikow
	 */
	public Set<Users> getSetOfConnectedUsers();
	
	/**
	 * Dodaje uzytkownika jesli nie istnieje uzytkownik z podanym username w
	 * przeciwnym przypadku aktualizuje port uzytkownika juz istniejacego
	 * 
	 * @param user
	 *            uzytkownik ktory ma zostac dodany lub zaaktualizowany w
	 *            zbiorze wszystkich uzytkownikow
	 */
	public void addUser(Users user);
	
	/**
	 * Usuwa uzytkownika o okreslonym porcie
	 * 
	 * @param index
	 *            - index uzytkownika w ziorze
	 */
	public void removeUser(int index);
	
	/**
	 * Usuwa podanego uzytkownika
	 * 
	 * @param user
	 *            - uzytkownik do usuniecia
	 */
	public void removeUser(Users user);
	
	/**
	 * Ustawia zbior uzytkownikow na podany
	 * 
	 * @param newUsers
	 *            zbior uzytkownikow ktory zostanie zapisany
	 */
	public void setAllUsersList(Set<Users> newUsers);
	
	/**
	 * sprawdza czy zbior uzytkownikow jest pusty
	 * 
	 * @return true gdy nie ma zadnych uzytkownikow
	 * @return false gdy istnieje uzytkownik
	 */
	public boolean isEmpty();
	
	/**
	 * Metoda zmienia pokoj uzytkownika z podana nazwa
	 * 
	 * @param userName
	 *            nazwa uzytkownika dla ktorego pokoj ma byc zmieniony
	 * @param newChatRoom
	 *            nowy pokoj uzytkownika
	 */
	public void changeRoom(String userName, ChatRoom newChatRoom);
	
	/**
	 * zwraca aktualny pokoj uzytkownika o podanej nazwie
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return chatRoom aktualny pokoj uzytkownika o podanej nazwie lub pokoj
	 *         domyslny jesli nie ma uzytkownika o podanej nazwie
	 */
	public ChatRoom getChatRoom(String userName);
	
	/**
	 * Sprawdza czy uzytkownik o podanej nazwie juz istnieje
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return true jestli uzytkownik istnieje w zbiorze
	 * @return false w przeciwnym przypadku
	 */
	public boolean containsUserWithName(String userName);
	
	/**
	 * Sprawdza czy uzytkownik o podanej nazwie i hasle istnieje
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @param password haslo uzytkownika
	 * @return true jestli uzytkownik istnieje w zbiorze
	 * @return false w przeciwnym przypadku
	 */
	public boolean containsUserWithData(String userName, String password);
	
	/**
	 * sprawdza czy nazwa pokoju czatu jest juz zajeta
	 * 
	 * @param chatRoomName
	 *            nazwa pokoju
	 * @return true jesli pokoj z podana nazwa juz istnieje
	 * @return false w przeciwnym przypadku
	 */
	public boolean containsChatRoomName(String chatRoomName);
	
	/**
	 * Zwraca liste nazw wszystkich uzytkownikow
	 * 
	 * @return nameAllUsers lista wszystkich uzytkownikow
	 */
	public ArrayList<String> getArrayOfNameAllUsers();
	
	/**
	 * Dodaje wiadomosc do przechowania dla uzytkownika o podanej nazwie
	 * 
	 * @param userName
	 *            nazwa uzytkownika dla ktorego przeznaczona jest wiadomosc
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 * @param messages
	 *            wiadomosci dla uzytkownika
	 */	
	public void addMessagesForUser(String userName, String nameSender, String messages);
	
	/**
	 * Zwraca wiadomosci przechowywane dla uzytkownika z podanym portem lub null
	 * jesli uzytkownik nie posiada wiadomosci
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return messagesForUser wiadomosci ktore uzytkownik otrzymal podczas
	 *         swojej nieobecnosci lub null jesli nie ma wiadomosci dla tego
	 *         uzytkownika
	 */
	public Map<String, String> getMessagesForUser(String userName);
	
	
	/**
	 * usuwa wiadomosci przechowywane dla uzytkownika o podanym porcie
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @param userNameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 */
	public void clearMessageForUser(String userName, String userNameSender);
	
	/**
	 * Zapisuje wszytskich uzytkownikow do pliku
	 */
	public void saveAllUsers();
}
