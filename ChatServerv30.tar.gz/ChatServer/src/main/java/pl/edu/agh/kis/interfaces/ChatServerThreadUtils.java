package main.java.pl.edu.agh.kis.interfaces;
import java.io.IOException;

public interface ChatServerThreadUtils {
	/**
	 * Usuwa wszystkich uzytkownikow ze zbioru polaczonych uzytkownikow oraz
	 * wysyla wiadomosc o ich rozlaczeniu
	 * 
	 * @param portRoot
	 *            localPort socketa roota
	 */
	void shutDownServer(int portRoot);

	/**
	 * Wysyla prywatna wiadomosc do odpowiedniego uzytkownika jesli jest
	 * polaczony w przeciwnym przypadku zapisuje wiadomosc
	 * 
	 * @param receiveMessage
	 *            wiadomosc z informacja o uzytkowniku ktory wyslal wiadomosc, o
	 *            odbiory i tresci wiadomosci prywatnej z input
	 * @throws IOException
	 */
	void sendPrivateMessage(String[] receiveMessage) throws IOException;

	/**
	 * Wysyla zaproszenie do odpowiedniego polaczonego uzytkownika, jesli
	 * uzytkownik nie jest polaczony zapisuje mu informacje o zaproszeniu
	 * 
	 * @param receiveMessage
	 *            wiadomosc z informacja o wyslaniu zaproszenia przez
	 *            uzytkownika do uzytkonika z input
	 * @throws IOException
	 */
	void sendInvite(String[] receiveMessage) throws IOException;

	/**
	 * Uaktualnia pokoje w zbiorze polaczonych uzytkownikow
	 * 
	 * @param receiveMessage
	 *            wiadomosc z informacja o zmianie pokoju z input
	 */
	void updateRoomInArray(String[] receiveMessage);

	/**
	 * Sprawdza czy socket jest polaczony oraz czy socket istnieje w tablicy
	 * uzytkownikow
	 * 
	 * @throws IOException
	 */
	void checkConnection() throws IOException;

	/**
	 * Sprawdza czy nazwa pokoju jest juz zajeta
	 * 
	 * @param data
	 *            [0] nazwa uzytkownika, data[1] nazwa pokoju, data[2]
	 *            dostepnosc pokoju
	 */
	void checkExistsRoom(String[] data);

	/**
	 * Wysyla wiadomosc do uzytkownikow z tego samego pokoju co uzytkownik
	 * wysylajacy wiadomosc
	 * 
	 * @param message
	 *            wiadomosc do wyslania
	 * @throws IOException
	 *             gdy proba wyslania wiadomosci sie nie powiedzie
	 */
	void sendMessageToCorrectRoom(String message) throws IOException;

}
