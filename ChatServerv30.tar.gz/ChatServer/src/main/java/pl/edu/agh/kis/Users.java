package main.java.pl.edu.agh.kis;

import java.io.IOException;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Klasa opisuje uzytkownika czatu localPort - na ktorym aktualnie jest
 * polaczony userName - unikalna nazwa uzytkownika chatRoom - pokoj w ktorym
 * aktualnie sie znajduje messageForUser - zalegle wiadomosci prywatne, gdzie
 * klucz to wiadomosc a wartosc to nazwa uzytkownika ktory wyslal wiadomosc
 * 
 * @author N.Materek
 * @see ChatRoom
 */
public class Users {

	private Socket socket = null;
	private int localPort;
	private String userName;
	private String password;
	private ChatRoom chatRoom;
	private Map<String, String> messagesForUser = Collections
			.synchronizedMap(new HashMap<String, String>());

	private void addLocalPort() {
		if (socket != null) {
			localPort = socket.getPort();
		}
	}

	public Users(String userName) {
		this.userName = userName;
	}

	public Users(Socket socket) {
		this.socket = socket;
		addLocalPort();
	}

	public Users(Socket socket, ChatRoom chatRoom) {
		this.socket = socket;
		this.chatRoom = chatRoom;
		addLocalPort();
	}

	public Users(Socket socket, String userName, String password,
			ChatRoom chatRoom) {
		this(socket, chatRoom);
		this.userName = userName;
		this.password = password;
		addLocalPort();
	}

	public Users(String userName, String password, ChatRoom chatRoom) {
		this.chatRoom = chatRoom;
		this.userName = userName;
		this.password = password;
		addLocalPort();
	}

	public Users(String userName, String password, ChatRoom chatRoom,
			Map<String, String> messagesForUsers) {
		this(userName, password, chatRoom);
		this.messagesForUser = messagesForUsers;
	}

	public Users(int localPort, String userName, String password,
			ChatRoom chatRoom) {
		this.localPort = localPort;
		this.chatRoom = chatRoom;
		this.password = password;
		this.userName = userName;
		addLocalPort();
	}

	public Socket getSocket() {
		return socket;
	}

	public String getRoomName() {
		return chatRoom.getRoomName();
	}

	public void setRoomName(String name, int available) {
		chatRoom.setRoomName(name, available);
	}

	public int getAvailableRoom() {
		return chatRoom.getAvailable();
	}

	public void setLocalPort(int currentLocalPort) {
		localPort = currentLocalPort;
	}

	public int getLocalPort() {
		return localPort;
	}

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Dodaje wiadomosc dla uzytkownika
	 * 
	 * @param nameSender
	 *            nazwa uzytkowika ktory wyslal wiadomosc
	 * @param message
	 *            tresc wiadomosci
	 */
	public void addMessagesForUser(String nameSender, String message) {
		messagesForUser.put(message, nameSender);
	}

	/**
	 * Zwraca wiadomosci dla uzytkownika key - wiadomosci value - nazwa
	 * uzytkownika ktory wyslal wiadomosc
	 * 
	 * @return mapa wiadomosci
	 */
	public Map<String, String> getMessagesForUser() {
		return messagesForUser;
	}

	/**
	 * Usuwa zalegle wiadomosci od konkretnego uzytkownika
	 * 
	 * @param userNameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosci
	 */
	public synchronized void clearMessagesForUser(String userNameSender) {
		for (Map.Entry<String, String> entry : messagesForUser.entrySet()) {
			if (entry.getValue().equals(userNameSender) == true) {
				messagesForUser.remove(entry.getKey());
				break;
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder messages = new StringBuilder();
		for (Map.Entry<String, String> entry : messagesForUser.entrySet()) {
			messages.append(entry.getValue() + ": " + entry.getKey() + " ");
		}
		return "Socket is: " + socket + ", user's name: " + userName
				+ " user's password: " + password + ", chatRoom's name: "
				+ chatRoom.getRoomName() + ", available: "
				+ chatRoom.getAvailable() + " localport is: " + localPort
				+ " not receive messages: " + messages;
	}

}
