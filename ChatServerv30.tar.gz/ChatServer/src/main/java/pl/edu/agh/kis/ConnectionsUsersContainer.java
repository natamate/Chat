package main.java.pl.edu.agh.kis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import main.java.pl.edu.agh.kis.interfaces.StoreData;


/**
 * Klasa zawiera zbior uzytkownikow aktualnie polaczonych i umozliwia operacje
 * 
 * @author N.Materek
 * @see StoreData
 */
public class ConnectionsUsersContainer implements StoreData {
	private static Set<Users> connectionUsers = Collections
			.synchronizedSet(new HashSet<Users>());

	/**
	 * Sprawdza czy uzytkownik o podanej nazwie jest zalogowany
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return true jestli uzytkownik istnieje w zbiorze
	 * @return false w przeciwnym przypadku
	 */
	public synchronized boolean containsUserWithName(String userName) {
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName() != null
					&& users.getUserName().equals(userName) == true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Sprawdza czy uzytkownik o podanej nazwie i hasle istnieje
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @param password
	 *            haslo uzytkownika
	 * @return true jestli uzytkownik istnieje w zbiorze
	 * @return false w przeciwnym przypadku
	 */
	public synchronized boolean containsUserWithData(String userName, String password) {
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName() != null
					&& users.getUserName().equals(userName) == true
					&& users.getPassword().equals(password) == true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Zwraca uzytkownika o okreslonym porcie jesli jest polaczony
	 * 
	 * @param localPort
	 *            - port socketa uzytkownika
	 * @return users uzytkownik o podanym porcie
	 */
	public synchronized Users getUser(int localPort) {
		for (Iterator<Users> it = connectionUsers.iterator(); it.hasNext();) {
			Users users = it.next();
			if (users.getLocalPort() == localPort) {
				return users;
			}
		}
		throw new RuntimeException("User nie istnieje");
	}
	
	/**
	 * Zwraca zbior polaczonych uzytkownikow
	 * 
	 * @return allUsers zbior wszystkich uzytkownikow
	 */
	public synchronized Set<Users> getSetOfConnectedUsers() {
		return connectionUsers;
	}

	/**
	 * Dodaje uzytkownika do zbioru polaczonych uzytkownikow
	 * 
	 * @param user
	 *            uzytkownik do dodania
	 */
	public synchronized void addUser(Users user) {
		connectionUsers.add(user);
	}

	/**
	 * Usuwa uzytkownika o okreslonym porcie
	 * 
	 * @param localPort
	 *            - port socketa uzytkownika
	 */
	public synchronized void removeUser(int localPort) {
		for (Iterator<Users> it = connectionUsers.iterator(); it.hasNext();) {
			Users users = it.next();
			if (users.getLocalPort() == localPort) {
				connectionUsers.remove(users);
				break;
			}
		}
	}

	/**
	 * usuwa podanego uzytkownika
	 * 
	 * @param user
	 *            uzytkownik ktory ma zostaca usuniety
	 */
	public synchronized void removeUser(Users user) {
		for (Iterator<Users> it = connectionUsers.iterator(); it.hasNext();) {
			Users users = it.next();
			if (user.getUserName().equals(users.getUserName())){
				connectionUsers.remove(users);
				break;
			}
		}
	}

	/**
	 * Ustawia zbior uzytkownikow na podany
	 * 
	 * @param newUsers
	 *            zbior uzytkownikow ktory zostanie zapisany
	 */
	public synchronized void setAllUsersList(Set<Users> newUsers) {
		connectionUsers = newUsers;
	}

	/**
	 * sprawdza czy zbior polaczonych uzytkownikow jest pusty
	 * 
	 * @return true gdy nie ma zadnych uzytkownikow
	 * @return false gdy istnieje polaczony uzytkownik
	 */
	public synchronized boolean isEmpty() {
		if (connectionUsers.isEmpty() == true) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Metoda zmienia pokoj uzytkownika o podanej nazwie uzytkownika
	 * 
	 * @param userName
	 *            nazwa uzytkownika dla ktorego pokoj ma byc zmieniony
	 * @param newChatRoom
	 *            nowy pokoj uzytkownika
	 */
	public synchronized void changeRoom(String userName, ChatRoom newChatRoom) {
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users user = i.next();
			if (user.getUserName().equals(userName) == true) {
				user.setRoomName(newChatRoom.getRoomName(),
						newChatRoom.getAvailable());
				break;
			}
		}
	}

	/**
	 * zwraca aktualny pokoj uzytkownika o podanej nazwie lub pokoj domyslny
	 * jesli nie ma polaczonego uzytkownika o podanej nazwie
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return chatRoom aktualny pokoj uzytkownika lub pokoj domyslny gdy nie
	 *         istnieje uzytkownik
	 */
	public synchronized ChatRoom getChatRoom(String userName) {
		ChatRoom chatroom = new ChatRoom(0, "public");
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				chatroom = new ChatRoom(users.getAvailableRoom(),
						users.getRoomName());
				return chatroom;
			}
		}
		return chatroom;
	}

	/**
	 * sprawdza czy nazwa pokoju czatu jest juz zajeta
	 * 
	 * @param chatRoomName
	 *            nazwa pokoju
	 * @return true jesli pokoj z podana nazwa juz istnieje
	 * @return false w przeciwnym przypadku
	 */
	public synchronized boolean containsChatRoomName(String chatRoomName) {
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getRoomName().equals(chatRoomName) == true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Zwraca liste nazw polaczonych uzytkownikow
	 * 
	 * @return nameAllUsers lista polaczonych uzytkownikow
	 */
	public synchronized ArrayList<String> getArrayOfNameAllUsers() {
		ArrayList<String> nameAllUsers = new ArrayList<>();
		Set<Users> allUsers = getSetOfConnectedUsers();
		for (Users user : allUsers) {
			nameAllUsers.add(user.getUserName());
		}
		return nameAllUsers;
	}

	/**
	 * Dodaje wiadomosc do przechowania dla uzytkownika o podanej nazwie
	 * 
	 * @param userName
	 *            nazwa uzytkownika dla ktorego przeznaczona jest wiadomosc
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 * @param messages
	 *            wiadomosci dla uzytkownika
	 */
	public synchronized void addMessagesForUser(String userName,
			String nameSender, String messages) {
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				users.addMessagesForUser(nameSender, messages);
			}
		}
	}

	/**
	 * Zwraca wiadomosci przechowywane dla uzytkownika z podana nazwa
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return messagesForUser wiadomosci ktore uzytkownik otrzymal podczas
	 *         swojej nieobecnosci
	 * @throws NullPointerException
	 */
	public synchronized Map<String, String> getMessagesForUser(String userName) {
		Map<String, String> messagesForUser = null;
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				messagesForUser = users.getMessagesForUser();
			}
		}
		return messagesForUser;
	}

	/**
	 * usuwa wiadomosci przechowywane dla uzytkownika o podanym porcie
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @param userNameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 */
	public synchronized void clearMessageForUser(String userName,
			String userNameSender) {
		for (Iterator<Users> it = connectionUsers.iterator(); it.hasNext();) {
			Users u = it.next();
			if (u.getUserName().equals(userName) == true) {
				u.clearMessagesForUser(userName);
			}
		}
	}

	public void saveAllUsers() {

	}

	/**
	 * Zwraca port socketa uzytkownika o podanej nazwie
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return localPort port socketa
	 */
	private synchronized int getLocalPort(String userName) {
		int localPort = 0;
		for (Iterator<Users> i = connectionUsers.iterator(); i.hasNext();) {
			Users users = i.next();
			if (users.getUserName().equals(userName) == true) {
				localPort = users.getLocalPort();
				return localPort;
			}
		}
		return localPort;
	}

}
