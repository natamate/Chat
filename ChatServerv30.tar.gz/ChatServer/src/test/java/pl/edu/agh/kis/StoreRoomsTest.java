package test.java.pl.edu.agh.kis;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import main.java.pl.edu.agh.kis.ChatRoom;
import main.java.pl.edu.agh.kis.ConnectionsUsersContainer;
import main.java.pl.edu.agh.kis.StoreRooms;
import main.java.pl.edu.agh.kis.Users;
import main.java.pl.edu.agh.kis.interfaces.StoreData;

import org.junit.Test;


public class StoreRoomsTest {
	private static StoreData test = new StoreRooms();

	private Users[] usersTab = { new Users(1234, "1", "1", new ChatRoom("public")),
			new Users(1233, "2", "2", new ChatRoom("room's 2")),
			new Users(1266, "3","3", new ChatRoom("room's 3")),
			new Users(1235, "4", "4", new ChatRoom("room's 4")),
			new Users(1277, "5", "5", new ChatRoom("room's 5")),
			new Users(null, "6", "6", new ChatRoom("room's 6")) };

	public Set<Users> initializeSet() {
		Set<Users> newSet = new HashSet<Users>();
		for (Users u : usersTab) {
			newSet.add(u);
		}
		return newSet;
	}

	public Set<Users> initializeNullSet() {
		return new HashSet<Users>();
	}

	@Test
	public void testContainsUserWithName() {
		test.setAllUsersList(initializeSet());

		for (int i = 1; i < 7; i++) {
			if (test.containsUserWithName(i + "") == false) {
				assertTrue(false);
			}
		}

		if (test.containsUserWithName(null) == true) {
			assertTrue(false);
		}

		assertTrue("Succed", true);
	}

	public boolean compareUsers(Users u1, Users u2) {
		if (u1.getLocalPort() != u2.getLocalPort()) {
			return false;
		}
		if (u1.getUserName().equals(u2.getUserName()) == false) {
			return false;
		}
		if (u1.getRoomName().equals(u2.getRoomName()) == false) {
			return false;
		}
		if (u1.getSocket() != null) {
			if (u1.getSocket().equals(u2.getSocket()) == false) {
				return false;
			}
		}
		if (u1.getLocalPort() != u2.getLocalPort()) {
			return false;
		}
		if (u1.getMessagesForUser().equals(u2.getMessagesForUser()) == false) {
			return false;
		}
		return true;
	}

	@Test
	public void testGetUser() {
		test.setAllUsersList(initializeSet());

		Users testUsers = test.getUser(1234);
		if (compareUsers(testUsers,
				new Users(1234, "1", "1", new ChatRoom("public"))) == false) {
			assertTrue(false);
		}

		try {
			if (test.getUser(666).equals(
					new Users(1235, "4", "4", new ChatRoom("room's 4"))) == true) {
				assertTrue(false);
			}
		} catch (Exception e) {
			assertTrue(true);
		}

		assertTrue(true);

	}

	@Test
	public void testGetSetOfConnectedUsers() {
		test.setAllUsersList(initializeSet());
		Set<Users> newSet = test.getSetOfConnectedUsers();

		for (Users u : usersTab) {
			if (newSet.contains(u) == false) {
				assertTrue(false);
			}
		}
		assertTrue(true);
	}

	public int getSizeSet() {
		int size = 0;
		for (Users u : test.getSetOfConnectedUsers()) {
			size++;
		}
		return size;
	}

	@Test
	public void testAddUser() {
		test.setAllUsersList(initializeNullSet());
		for (Users u : usersTab) {
			test.addUser(u);
		}
		if (test.getSetOfConnectedUsers().isEmpty() == true) {
			assertTrue(false);
		}

		if (getSizeSet() != 6) {
			assertTrue(false);
		}

		Users[] usersTab2 = { new Users(1239, "1", "1", new ChatRoom("public")),
				new Users(1240, "2", "2",new ChatRoom("room's 2")),
				new Users(1267, "3", "3", new ChatRoom("room's 3")),
				new Users(1245, "4", "4", new ChatRoom("room's 4")),
				new Users(1288, "5", "5", new ChatRoom("room's 5")),
				new Users(null, "6", "6", new ChatRoom("room's 6")) };

		for (Users u : usersTab2) {
			test.addUser(u);
		}

		if (getSizeSet() != 6) {
			assertTrue(false);
		}

		printSet("AddUser");
		assertTrue(true);
	}

	public void printSet(String function) {
		Set<Users> users = test.getSetOfConnectedUsers();
		int counter = 0;
		System.out.println(function);
		for (Users u : users) {
			System.out.println(counter++ + ": " + u);
		}
	}

	@Test
	public void testRemoveUserInt() {
		test.setAllUsersList(initializeSet());
		test.removeUser(1234);
		test.removeUser(10);
		test.removeUser(1233);
		printSet("RemoveUserInt");

		if (getSizeSet() != 4) {
			assertTrue("Size is: " + getSizeSet(), false);
		}

		assertTrue(true);
	}

	@Test
	public void testRemoveUserUsers() {
		test.setAllUsersList(initializeSet());

		test.removeUser(usersTab[0]);
		test.removeUser(usersTab[5]);
		test.removeUser(usersTab[3]);

		printSet("RemoveUserUsers");

		if (test.containsUserWithName(usersTab[0].getUserName()) == true) {
			assertTrue(false);
		}
		if (test.containsUserWithName(usersTab[3].getUserName()) == true) {
			assertTrue(false);
		}
		if (test.containsUserWithName(usersTab[5].getUserName()) == true) {
			assertTrue(false);
		}

		assertTrue(true);
	}

	@Test
	public void testSetAllUsersList() {
		test.setAllUsersList(initializeSet());
		if (getSizeSet() != 6) {
			assertTrue(false);
		}

		test.setAllUsersList(initializeNullSet());
		if (getSizeSet() != 0) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void testChangeRoom() {
		test.setAllUsersList(initializeSet());
		test.changeRoom("1", new ChatRoom(1, "nowyRoomdla1"));
		test.changeRoom("2", new ChatRoom("NowyChatRoom"));

		ChatRoom User1234 = test.getChatRoom("1");
		if ((User1234.getRoomName().equals("nowyRoomdla1") == false)
				|| User1234.getAvailable() != 1) {
			assertTrue(test.getChatRoom("1").getRoomName() + " "
					+ test.getChatRoom("1").getAvailable(), false);
		}
		ChatRoom User1233 = test.getChatRoom("2");
		if ((User1233.getRoomName().equals("NowyChatRoom") == false)
				|| User1233.getAvailable() != 0) {
			assertTrue(test.getChatRoom("2").getRoomName() + " "
					+ test.getChatRoom("2").getAvailable(), false);
		}

		try {
			test.changeRoom("211", new ChatRoom("NowyChatRoom"));
		} catch (Exception e) {
			assertTrue(false);
		}
		assertTrue(true);

	}

	@Test
	public void testGetChatRoom() {
		test.setAllUsersList(initializeSet());
		printSet("GetChatRoom");
		ChatRoom user1234 = test.getChatRoom("1");
		if ((user1234.getRoomName().equals("public") == false)
				|| user1234.getAvailable() != 0) {
			assertTrue(test.getChatRoom("1").getRoomName() + " "
					+ test.getChatRoom("1").getAvailable(), false);
		}
		ChatRoom user1233 = test.getChatRoom("2");
		if ((user1233.getRoomName().equals("room's 2") == false)
				|| user1233.getAvailable() != 0) {
			assertTrue(test.getChatRoom("2").getRoomName() + " "
					+ test.getChatRoom("2").getAvailable(), false);
		}

		ChatRoom userNotExist = test.getChatRoom("1111");
		if (userNotExist.getRoomName().equals("public") == false || userNotExist.getAvailable() != 0){
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void testAddMessagesForUser() {

		test.setAllUsersList(initializeSet());
		String[] ms = { "messages1", "messages2", "messages3" };
		int key = 2;

		for (String s : ms) {
			test.addMessagesForUser("1", key + "", s);
			printSet("addMessages");
			key++;
		}

		Map<String, String> messages = test.getMessagesForUser("1");
		printSet("addMessages");

		for (String s : ms) {
			if (messages.containsKey(s) == false) {
				assertTrue(false);
			}
		}
		if (messages.containsValue("2") == false) {
			assertTrue(false);
		}

		test.setAllUsersList(initializeNullSet());
		try {
			test.addMessagesForUser("Users", "1", "messages");
		} catch (Exception e) {
			assertTrue(true);
		}

	}

	@Test
	public void testGetMessagesForUser() {

		test.setAllUsersList(initializeSet());
		int key = 2;
		String[] ms = { "messages1", "messages2", "messages3" };
		for (String s : ms) {
			test.addMessagesForUser("1", key+"", s);
			key++;
		}

		Map<String,String> messages = test.getMessagesForUser("1");
		key = 2;
		for (String s : ms) {
			if (messages.containsKey(s) == false) {
				assertTrue(false);
			}
			if (messages.containsValue(key+"") == false){
				assertTrue(false);
			}
			key++;
		}
		test.setAllUsersList(initializeNullSet());
		try {
			test.addMessagesForUser("Users", "SOMEONE", "messages");
		} catch (Exception e) {
			assertTrue(true);
		}

	}

	@Test
	public void testContainsChatRoomName() {
		test.setAllUsersList(initializeSet());

		if (test.containsChatRoomName("room's 2") == false) {
			assertTrue(false);
		}
		if (test.containsChatRoomName("PokojKtoregoNieMa") == true) {
			assertTrue(false);
		}
		if (test.containsChatRoomName("public") == false) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void testGetArrayOfNameAllUsers() {
		test.setAllUsersList(initializeSet());
		ArrayList<String> allName = test.getArrayOfNameAllUsers();

		String[] names = { "1", "2", "3", "4", "5", "6" };

		for (String name : names) {
			if (allName.contains(name) == false) {
				assertTrue(false);
			}
		}
		assertTrue(true);
	}

}
