package test.java.pl.edu.agh.kis;

import static org.junit.Assert.*;

import java.awt.image.DataBufferInt;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import main.java.pl.edu.agh.kis.*;
import main.java.pl.edu.agh.kis.interfaces.UsersDatabase;

import org.junit.Test;

public class DataBaseInFileTest {
	UsersDatabase dataBase = new DataBaseInFile();

	Set<Users> listUsers = new HashSet<>();

	Users[] allUsers = { new Users(2, "2", "2", new ChatRoom(0, "2's rooms")),
			new Users(1, "1", "1", new ChatRoom(0, "1's rooms")),
			new Users(3, "3", "3", new ChatRoom(0, "3's rooms")) };

	public void initializeList() {
		dataBase.setPath("src/test/resources/pl/edu/agh/kis/UsersTest.txt");
		for (Users u : allUsers) {
			listUsers.add(u);
		}
	}

	@Test
	public void testWriteToFile() {
		initializeList();
		try {
			dataBase.writeToFile(listUsers);
		} catch (FileNotFoundException e) {
			assertTrue(false);
		} catch (IOException e) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	public boolean containsUser(Users u) {
		for (Users user : listUsers) {
			System.out.println(user + " == " + u);
			if (user.getUserName().equals(u.getUserName())
					&& user.getPassword().equals(u.getPassword())
					&& user.getRoomName().equals(u.getRoomName())) {
				return true;
			}
		}
		return false;
	}

	@Test
	public void testReadFromFile() {
		initializeList();
		for (Users u : allUsers) {
			System.out.println("ALL " + u);
		}
		try {
			dataBase.writeToFile(listUsers);

			listUsers = null;

			listUsers = dataBase.readFromFile();

			for (Users u : listUsers) {
				System.out.println(u);
			}
			for (Users u : allUsers) {
				if (containsUser(u) == false) {
					assertTrue(false);
				}
			}
		} catch (FileNotFoundException e) {
			assertTrue(false);
		} catch (IOException e) {
			assertTrue(false);
		}
		assertTrue(true);

	}
	
}
