package test.java.pl.edu.agh.kis;

import static org.junit.Assert.*;

import main.java.pl.edu.agh.kis.DefinitionNews;
import main.java.pl.edu.agh.kis.interfaces.SupportMessages;

import org.junit.Test;

public class DefinitionNewsTest {

	SupportMessages message = new DefinitionNews();

	@Test
	public void testMakeDefinitionNews() {
		message.makeDefinitionNews("zwykla wiadomosc");

		if (message.getMessage()[0] == null) {
			assertTrue(false);
		}

		if (message.getMessage()[0].equals("zwykla wiadomosc") == false) {
			assertTrue(false);
		}

		message.makeDefinitionNews("#@$!ADDUSER#@!$11");

		if (message.getMessage() == null) {
			assertTrue(false);
		}

		if (message.getMessage()[0].equals("11") == false) {
			assertTrue(false);
		}

		message.makeDefinitionNews("#@$!ADDROOM#@!$user, room, 1");

		if (message.getMessage() == null) {
			assertTrue(false);
		}

		if (message.getMessage()[0].equals("user") == false) {
			assertTrue(false);
		} else if (message.getMessage()[1].equals("room") == false) {
			assertTrue(false);
		} else if (message.getMessage()[2].equals("1") == false) {
			assertTrue(false);
		}
		assertTrue(true);
	}

	@Test
	public void testGetTypeMessage() {
		message.makeDefinitionNews("zwykla wiadomosc");

		if (message.getTypeMessage() != 0) {
			assertTrue(false);
		}

		message.makeDefinitionNews("#@$!ADDUSER#@!$11");
		if (message.getTypeMessage() != 1) {
			assertTrue(false);
		}

		message.makeDefinitionNews("#@$!ADDROOM#@!$user, room, 1");
		if (message.getTypeMessage() != 2) {
			assertTrue(false);
		}
		assertTrue(true);
	}

}
