package test.java.pl.edu.agh.kis;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import main.java.pl.edu.agh.kis.ChatRoom;
import main.java.pl.edu.agh.kis.Users;

import org.junit.Test;


public class UsersTest {

	String[] msg = { "message1", "message2", "message3" };
	Users test;
	
	public Users initializeMessage() {
		test = new Users("1", "1", new ChatRoom("public"));
		int value = 0;
		for (String s : msg) {
			test.addMessagesForUser(value + "", s);
			value++;
		}
		return test;
	}

	public void print(Users test) {
		Map<String, String> messages = test.getMessagesForUser();

		for (Map.Entry<String, String> entry : messages.entrySet()) {
			System.out.print("key is: " + entry.getKey() + " & Value is: ");
			System.out.println(entry.getValue());
		}
	}

	@Test
	public void testAddMessagesForUser() {

		Users test = initializeMessage();
		Map<String, String> messages = test.getMessagesForUser();

		for (String s : msg) {
			if (messages.containsKey(s) == false) {
				assertTrue(false);
			}
		}

		for (int i = 0; i < 3; i++) {
			if (messages.containsValue(i+"") == false) {
				assertTrue(false);
			}
		}
		assertTrue(true);
	}

	@Test
	public void testGetMessagesForUser() {
		Users test = initializeMessage();
		Map<String, String> messages = test.getMessagesForUser();
		for (String s : msg) {
			if (messages.containsKey(s) == false) {
				assertTrue(false);
			}
		}

		for (int i = 0; i < 3; i++) {
			if (messages.containsValue(i+"") == false) {
				assertTrue(false);
			}
		}
		assertTrue(true);
	}

	@Test
	public void testClearMessagesForUser() {
		Users test = initializeMessage();
		test.clearMessagesForUser("0");
		test.clearMessagesForUser("1");
		test.clearMessagesForUser("2");
		Map<String, String> messages = test.getMessagesForUser();
		for (String s : msg) {
			if (messages.containsValue(s) == true) {
				assertTrue(false);
			}
		}
		if (messages.isEmpty() == true) {
			assertTrue(true);
		}
	}

}
