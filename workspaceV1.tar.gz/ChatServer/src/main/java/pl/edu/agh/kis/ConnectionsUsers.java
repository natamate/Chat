package main.java.pl.edu.agh.kis;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import javax.swing.JOptionPane;

import main.java.pl.edu.agh.kis.interfaces.ModificationsConnectedUsers;
import main.java.pl.edu.agh.kis.interfaces.StoreData;


/**
 * Pozwala na dostep do danych o polaczonych uzytkownikach, aktualizuje dane o
 * uzytkownikach
 * 
 * @author N.Materek
 * @see ModificationsConnectedUsers
 * @see StoreData
 * 
 */
public class ConnectionsUsers implements ModificationsConnectedUsers {

	private static StoreData connectionsUsers = new ConnectionsUsersContainer();
	final static String[] commandArray = { "#@$!ADDUSER#@!$",
			"#@$!ADDROOM#@!$", "#@$!INVITES#@!$", "#@$!INFROOM#@!$",
			"#@$!SENDINVITE#", "#@$!PRIVMES#@!$", "#@$!DISCONNECT#",
			"#@$!MESSAGE@#$!", "#@$!SHUTDOWN#@!", "#@$!CHECKROOM#@", "#@$!THROWING#@!" };

	private static boolean running = true;

	private void addToSetConnectUser(Users newUser) throws IOException {
		if (connectionsUsers.containsUserWithName(newUser.getUserName()) == true) {

			Set<Users> connectUsers = connectionsUsers.getSetOfConnectedUsers();

			for (Iterator<Users> i = connectUsers.iterator(); i.hasNext();) {
				Users users = i.next();
				if (users.getUserName() != null
						&& users.getUserName().equals(newUser.getUserName()) == true) {
					users.getSocket().close();
					removeUser(users);
				}
			}
		}
		System.out.println("addToSETCONNECTUSER");
		printCurrentUsers();
		connectionsUsers.addUser(newUser);
		ChatServer.allUsers.addUser(newUser);
	}

	@Override
	/**
	 * Aktualizuje nazwe nowego uzytkownika w zbiorze polaczonych uzytkownikow  
	 * @param newUser socket nowego uzytkownika
	 * @throws IOException
	 */
	public synchronized void addUserName(Socket newUser) throws IOException {
		Scanner input = new Scanner(newUser.getInputStream());
		String[] dataAboutUser = input.nextLine().split(", ");
		boolean ifInCorrect = false;

		String userName = dataAboutUser[0];
		String password = dataAboutUser[1];

		if (ChatServer.allUsers.containsUserWithName(userName) == false) {
			ChatRoom currentChatRoom = new ChatRoom(0, "public");
			Users toAdd = new Users(newUser, userName, password,
					currentChatRoom);
			addToSetConnectUser(toAdd);
		}

		if (ChatServer.allUsers.containsUserWithData(userName, password) == false) {
			// newUser.close();
			System.out.println("System not contain such user");
			ifInCorrect = true;
			PrintWriter out = new PrintWriter(newUser.getOutputStream());
			out.println(commandArray[10] + userName);
			out.flush();
			//newUser.close();
			JOptionPane.showMessageDialog(null, "incorrect password!");
			//PrintWriter out = new PrintWriter(newUser.getOutputStream());
			//out.println("#@$!DISCONNECT#" + "\n");
			//out.flush();
		} else {
			ChatRoom currentChatRoom = new ChatRoom(0, "public");
			if (ChatServer.allUsers.containsUserWithData(userName, password)) {
				currentChatRoom = ChatServer.allUsers.getChatRoom(userName);
			}
			Users toAdd = new Users(newUser, userName, password,
					currentChatRoom);
			addToSetConnectUser(toAdd);
		}

		if (ifInCorrect == false) {
			try {
				sendNewVisibleList();
				updateRoomsList();
				updateNotReceiverMessages();

			} catch (IOException e) {
				ChatServer.logs.addError("IOException " + e.getStackTrace());
				ChatServer.logs
						.appendStatementToFile("ChatServerException.txt");
				e.printStackTrace();
			}
		}

		System.out.println("addUserName()");
		printCurrentUsers();
	}

	@Override
	public void printCurrentUsers() {
		Set<Users> allUsers = ChatServer.allUsers.getSetOfConnectedUsers();

		System.out.println("Begin all array");
		for (Users u : allUsers) {
			System.out.println("All : " + u);
		}
		System.out.println("End all array");

		Set<Users> connectUsers = connectionsUsers.getSetOfConnectedUsers();
		System.out.println("Begin connect array");
		for (Users u : connectUsers) {
			System.out.println("Connect : " + u);
		}
		System.out.println("End connect array");
	}

	/**
	 * Zwraca liste nazw polaczonych uzytkownikow
	 * 
	 * @return currentUsers nazwy aktualnie polaczonych uzytkownikow
	 */
	private ArrayList<String> makeListCurrentUsers() {
		ArrayList<String> currentUsers = connectionsUsers
				.getArrayOfNameAllUsers();
		return currentUsers;
	}

	/**
	 * Wysyla aktualna liste polaczonych uzytkownikow do polaczonych
	 * uzytkownikow
	 * 
	 * @throws IOException
	 */
	@Override
	public void sendNewVisibleList() throws IOException {
		Set<Users> currentConnectedUsers = connectionsUsers
				.getSetOfConnectedUsers();

		System.out.println("SendNewVisibleList");
		printCurrentUsers();

		for (Users user : currentConnectedUsers) {

			Socket tmp = user.getSocket();

			PrintWriter out = new PrintWriter(tmp.getOutputStream());

			ArrayList<String> currentUsers = makeListCurrentUsers();
			ArrayList<String> allUsers = ChatServer.allUsers
					.getArrayOfNameAllUsers();

			out.print(commandArray[0]);
			for (String s : currentUsers) {
				System.out.println(s);
				if (s.equals("root") == true) {
					continue;
				}
				out.print(s + ", ");
			}

			for (String s : allUsers) {
				System.out.println(s);
				if (s.equals("root") == true) {
					continue;
				}
				out.print(s + ", ");
			}
			out.print("\n");
			out.flush();
		}
	}

	/**
	 * Aktualizuje pokoje w zbiorze wszytskich uzytkownikow
	 */
	private void updateAllUSersArray() {
		Set<Users> allUsers = connectionsUsers.getSetOfConnectedUsers();
		for (Users user : allUsers) {
			if (ChatServer.allUsers.containsUserWithName(user.getUserName())
					&& ChatServer.allUsers.getChatRoom(user.getUserName())
							.equals(user.getRoomName()) == false) {
				ChatServer.allUsers.changeRoom(
						user.getUserName(),
						new ChatRoom(user.getAvailableRoom(), user
								.getRoomName()));
			}
		}
	}

	@Override
	/**
	 * wysyla wiadomosc do polaczonych uzytkownikow o dostepnych pokojach,
	 * dostepne pokoje maja available = 0
	 */
	public void updateRoomsList() {
		System.out.println("updateAllUsersArray");
		printCurrentUsers();
		updateAllUSersArray();
		try {
			Map<String, ChatRoom> userWithrooms = new HashMap<>();
			Set<Users> connectUsers = connectionsUsers.getSetOfConnectedUsers();
			Set<Users> allUsers = ChatServer.allUsers.getSetOfConnectedUsers();

			for (Users user : allUsers) {
				if (userWithrooms.containsKey(user.getUserName()) == false) {
					userWithrooms.put(
							user.getUserName(),
							new ChatRoom(user.getAvailableRoom(), user
									.getRoomName()));
				}
			}

			for (Users user : connectUsers) {
				Socket tmp = (Socket) user.getSocket();
				PrintWriter out = new PrintWriter(tmp.getOutputStream());

				out.print(commandArray[1]);
				for (Map.Entry<String, ChatRoom> entry : userWithrooms
						.entrySet()) {
					ChatRoom tmpRoom = entry.getValue();
					out.print(entry.getKey() + ": " + tmpRoom.getRoomName()
							+ ": " + tmpRoom.getAvailable() + ", ");
				}

				out.print("\n");
				out.flush();
			}

		} catch (IOException e) {
			e.getStackTrace();
		}
		System.out.println("updateRoomsList");
		printCurrentUsers();
	}

	@Override
	/**
	 * Sprawdza czy polaczony uzytkownik nie ma zaleglych wiadomosci,
	 * dodaje wiadomosci do wyslania jesli istnieja
	 */
	public void updateNotReceiverMessages() {
		Set<Users> connectUsers = connectionsUsers.getSetOfConnectedUsers();
		for (Users user : connectUsers) {
			Map<String, String> currentMessages = null;
			if (ChatServer.allUsers.containsUserWithName(user.getUserName()) == true) {
				currentMessages = ChatServer.allUsers.getMessagesForUser(user
						.getUserName());
			}

			ArrayList<String> senderNames = new ArrayList<>();

			if (currentMessages != null) {
				for (Map.Entry<String, String> entry : currentMessages
						.entrySet()) {
					user.addMessagesForUser(entry.getValue(), entry.getKey());
					sendInfoAboutMessages(user.getLocalPort(),
							entry.getValue(), entry.getKey());
					if (senderNames.contains(entry.getValue()) == false) {
						senderNames.add(entry.getValue());
					}
				}
			}

			for (String s : senderNames) {
				ChatServer.allUsers.clearMessageForUser(user.getUserName(), s);
			}
		}
		connectionsUsers.setAllUsersList(connectUsers);
	}

	/**
	 * Dodaje uzytkownika
	 * 
	 * @param newUser
	 *            uzytkownik do dodania
	 */
	public void addUser(Users newUser) {
		connectionsUsers.addUser(newUser);
	}

	/**
	 * Zwraca zbior aktualnie polaczonych uzytkownikow
	 * 
	 * @return zbior polaczonych uzytkownikow
	 */
	public Set<Users> getAllConnectedUsers() {
		return connectionsUsers.getSetOfConnectedUsers();
	}

	/**
	 * Usuwa podanego uzytkownika
	 * 
	 * @param toRemove
	 *            uzytkownik do usuniecia
	 */
	public void removeUser(Users toRemove) {
		connectionsUsers.removeUser(toRemove.getLocalPort());
		try {
			sendNewVisibleList();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Usuwa uzytkownika z podana nazwa
	 * 
	 * @param nameToRemove
	 *            nazwa uzytkownika do usuniecia
	 */
	public void removeUser(String nameToRemove) {
		Set<Users> connect = ChatServer.connectionUsers.getAllConnectedUsers();
		for (Users user : connect) {
			if (user.getUserName().equals(nameToRemove)) {
				connectionsUsers.removeUser(user);
				break;
			}
		}
		try {
			sendNewVisibleList();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * sprawdza czy jest polaczony uzytkownik z podanym portem
	 * 
	 * @param localPort
	 *            port socketa uzytkownika
	 * @return true jesli uzytkownik jest polaczony
	 * @return false w przeciwnym przypadku
	 */
	public boolean containsUser(int localPort) {
		Set<Users> connectionUsers = connectionsUsers.getSetOfConnectedUsers();
		for (Iterator<Users> it = connectionUsers.iterator(); it.hasNext();) {
			Users users = it.next();
			if (users.getLocalPort() == localPort) {
				return true;
			}
		}
		return false;
	}

	/**
	 * sprawdza czy jest polaczony uzytkownik z podana nazwa uzytkownika
	 * 
	 * @param userName
	 *            nazwa uzytkownika
	 * @return true jesli uzytkownik jest polaczony
	 * @return false w przeciwnym przypadku
	 */
	public boolean containsUserWithName(String userName) {
		Set<Users> connectionUsers = connectionsUsers.getSetOfConnectedUsers();
		for (Iterator<Users> it = connectionUsers.iterator(); it.hasNext();) {
			Users users = it.next();
			if (users.getUserName().equals(userName) == true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Zwraca nazwe pokoju w ktorym jest uzytkownik o podanym porcie
	 * 
	 * @param localPort
	 *            port socketa uzytkownika
	 * @return nazwa pokoju w ktorym jest obecnie uzytkownik lub nazwe pokoju
	 *         domyslnego jesli nie ma uzytkownika o podanym porcie
	 */
	public String getChatRoomName(int localPort) {
		Set<Users> connectionUsers = connectionsUsers.getSetOfConnectedUsers();
		for (Iterator<Users> it = connectionUsers.iterator(); it.hasNext();) {
			Users users = it.next();
			if (users.getLocalPort() == localPort) {
				return users.getRoomName();
			}
		}
		return "public";
	}

	public void changeChatRoom(String userName, ChatRoom newChatRoom) {
		connectionsUsers.changeRoom(userName, newChatRoom);
	}

	/**
	 * Zwraca flage okreslajaca czy serwer ma chodzic
	 * 
	 * @return running - true jesli serwer ma chodzic, false w przeciwnym
	 *         przypadku
	 */
	public boolean getFlag() {
		return running;
	}

	/**
	 * Ustawia flage
	 * 
	 * @param Flag
	 *            true jesli serwer ma chodzic, false jesli ma sie zatrzymac
	 */
	public void setFlag(boolean flag) {
		running = flag;
	}

	/**
	 * Rozlacza wszystkich uzytkownikow i ustawia flage pracy serwera na false
	 */
	public void disconnectAllUsers() {
		if (connectionsUsers.isEmpty() == false) {
			Set<Users> emptySet = null;
			connectionsUsers.setAllUsersList(emptySet);
		}
		running = false;
	}

	/**
	 * wysyla informacje do uzytkownika ktory ma dostac wiadomosc
	 * 
	 * @param localPortReceiver
	 *            port socketa uzytkownika ktory ma otrzymac wiadomosc
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 * @param message
	 *            tresc wiadomosci
	 */
	private void sendInfoAboutMessages(int localPortReceiver,
			String nameSender, String message) {
		Users receiver = connectionsUsers.getUser(localPortReceiver);
		try {
			Socket tmp = (Socket) receiver.getSocket();
			PrintWriter out = new PrintWriter(tmp.getOutputStream());

			out.print(commandArray[7]);
			out.print(nameSender + ", " + receiver.getUserName() + ", "
					+ message);
			out.print("\n");
			out.flush();

			System.out.println("After send info about message");
			printCurrentUsers();
		} catch (IOException e) {
			System.err.println();
		}
	}

	public synchronized boolean checkIfRoot(int localPort) {
		Users ifRoot = connectionsUsers.getUser(localPort);
		if (ifRoot.getUserName().equals("root") == true) {
			return true;
		} else {
			return false;
		}
	}

}
