package main.java.pl.edu.agh.kis;

import java.net.*;
import java.sql.Array;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.io.*;

import javax.swing.JOptionPane;

import main.java.pl.edu.agh.kis.interfaces.AppearanceMessages;
import main.java.pl.edu.agh.kis.interfaces.SupportMessages;


public class ChatServerThread implements Runnable {

	private Socket socket = null;
	private Scanner input;
	private PrintWriter out;
	private SupportMessages message = new DefinitionNews();

	public ChatServerThread(Socket socket) {
		this.socket = socket;
	}

	/**
	 * Sprawdza czy socket jest polaczony.
	 * 
	 * @throws IOException
	 */
	private void checkConnection() throws IOException {

		if (socket.isClosed() == true) {
			System.out.println("SOCKET IS CLOSED");
			Set<Users> connectUsers = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Users user : connectUsers) {
				Socket tmpSocket = user.getSocket();
				if (user.getSocket().equals(socket)) {
					System.out.println(tmpSocket.getLocalAddress()
							.getHostName() + " disconnected");
					ChatServer.allUsers.saveAllUsers();
					ChatServer.connectionUsers.removeUser(user);
				}
			}

			ChatServer.connectionUsers.sendNewVisibleList();
		}

		if (ChatServer.connectionUsers.containsUser(socket.getPort()) == false) {
			//PrintWriter out = new PrintWriter(socket.getOutputStream());
			//out.println("#@$!DISCONNECT#" + "\n");
			//out.flush();
			socket.close();
			//JOptionPane.showMessageDialog(null, "You disconnected");
			//System.exit(0);
		}

	}

	/**
	 * Konwertuje ciag znakow do liczby
	 * 
	 * @param number
	 *            liczba jako ciagu znakow
	 * @throw NumberFormatException
	 * @return liczba typu int
	 */
	private int convertFromString(String number) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			System.err.println(e.getStackTrace());
			throw new RuntimeException("Number Format Exception");
		}
	}

	/**
	 * Uaktualnia pokoje w zbiorze polaczonych uzytkownikow
	 * 
	 * @param receiveMessage
	 *            wiadomosc z informacja o zmianie pokoju z input
	 */
	private void updateRoomInArray(String[] receiveMessage) {

		String userName = receiveMessage[0];

		ChatServer.connectionUsers.changeChatRoom(userName, new ChatRoom(
				receiveMessage[2], receiveMessage[1]));
		System.out.println("Update room in array");
		ChatServer.connectionUsers.printCurrentUsers();
	}

	/**
	 * Wysyla zaproszenie do odpowiedniego polaczonego uzytkownika, jesli
	 * uzytkownik nie jest polaczony zapisuje mu informacje o zaproszeniu
	 * 
	 * @param receiveMessage
	 *            wiadomosc z informacja o wyslaniu zaproszenia przez
	 *            uzytkownika do uzytkonika z input
	 * @throws IOException
	 */
	private void sendInvite(String[] receiveMessage) throws IOException {

		String nameSender = receiveMessage[0];
		String nameReceiver = receiveMessage[1];
		String nameChatRoom = receiveMessage[2];

		if (ChatServer.connectionUsers.containsUserWithName(nameReceiver) == true) {
			Set<Users> connectedUsers = ChatServer.connectionUsers
					.getAllConnectedUsers();
			for (Users u : connectedUsers) {
				if (u.getUserName().equals(nameReceiver) == true) {
					sendMessageToChoosen(u.getLocalPort(), "Hej ! "
							+ nameReceiver + " You invited to room by "
							+ nameSender + "\n");
					sendMessageToChoosen(u.getLocalPort(),
							ConnectionsUsers.commandArray[2] + nameSender
									+ ", " + nameReceiver + ", " + nameChatRoom);
				}
			}
		} else {
			ChatServer.allUsers.addMessagesForUser(nameReceiver, nameSender,
					"The user: " + nameSender + " send you a invitation");
		}
	}

	/**
	 * Wysyla prywatna wiadomosc do odpowiedniego uzytkownika jesli jest
	 * polaczony w przeciwnym przypadku zapisuje wiadomosc
	 * 
	 * @param receiveMessage
	 *            wiadomosc z informacja o uzytkowniku ktory wyslal wiadomosc, o
	 *            odbiory i tresci wiadomosci prywatnej z input
	 * @throws IOException
	 */
	private void sendPrivateMessage(String[] receiveMessage) throws IOException {

		String nameSender = receiveMessage[0];
		String nameReceiver = receiveMessage[1];
		String message = receiveMessage[2];

		if (ChatServer.connectionUsers.containsUserWithName(nameReceiver) == true) {
			Set<Users> connectedUsers = ChatServer.connectionUsers
					.getAllConnectedUsers();
			for (Users u : connectedUsers) {
				if (u.getUserName().equals(nameReceiver) == true) {

					sendMessageToChoosen(u.getLocalPort(), "Hej "
							+ nameReceiver + "! The: " + nameSender
							+ " send you a private message : " + "\n" + message
							+ "\n");
					sendMessageToChoosen(u.getLocalPort(),
							ConnectionsUsers.commandArray[7] + nameSender
									+ ", " + nameReceiver + ", " + message
									+ "\n");
				}
			}
		} else {
			ChatServer.allUsers.addMessagesForUser(nameReceiver, nameSender,
					message);
		}
	}

	/**
	 * Usuwa wszystkich uzytkownikow ze zbioru polaczonych uzytkownikow
	 * 
	 * @param portRoot
	 *            localPort socketa roota
	 */
	private void shutDownServer(int portRoot) {

		synchronized (ChatServer.connectionUsers) {
			Set<Users> connected = ChatServer.connectionUsers
					.getAllConnectedUsers();
			for (Users u : connected) {
				try {
					if (u.getLocalPort() == portRoot) {
						continue;
					}
					sendMessageToChoosen(u.getLocalPort(), "Server is closed");

					Socket tmpSocket = u.getSocket();
					PrintWriter tmpOut = new PrintWriter(
							tmpSocket.getOutputStream());
					tmpOut.println(ConnectionsUsers.commandArray[6]
							+ u.getLocalPort());
					tmpOut.flush();
					System.out.println("Send to: "
							+ tmpSocket.getLocalAddress().getHostName());

				} catch (IOException e) {
					e.printStackTrace();
				} catch (ConcurrentModificationException e) {
					e.printStackTrace();
				}
			}

			System.out.println("SHUTDOWN");

		}
		ChatServer.connectionUsers.setFlag(false);
		System.out.println("Flag: " + ChatServer.connectionUsers.getFlag());

	}

	/**
	 * Sprawdza czy nazwa pokoju jest juz zajeta
	 * 
	 * @param data
	 *            [0] nazwa uzytkownika, data[1] nazwa pokoju, data[2]
	 *            dostepnosc pokoju
	 */
	private void checkExistsRoom(String[] data) {
		String userName = data[0];
		String roomName = data[1];
		String available = data[2];

		if (ChatServer.allUsers.containsChatRoomName(roomName) == false) {
			System.out.println(data[0] + " room is : " + data[1] + " "
					+ data[2]);
			updateRoomInArray(data);
			ChatServer.connectionUsers.updateRoomsList();

		} else {
			JOptionPane
					.showMessageDialog(null, "The name of the room is busy.");
		}
	}

	/**
	 * Wysyla wiadomosc do uzytkownikow z tego samego pokoju co uzytkownik
	 * wysylajacy wiadomosc
	 * 
	 * @param message
	 *            wiadomosc do wyslania
	 * @throws IOException
	 *             gdy proba wyslania wiadomosci sie nie powiedzie
	 */
	private void sendMessageToCorrectRoom(String message) throws IOException {

		if (ChatServer.connectionUsers.checkIfRoot(socket.getPort()) == true) {
			Set<Users> connectUser = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Iterator<Users> i = connectUser.iterator(); i.hasNext();) {
				Users users = i.next();
				sendMessageToChoosen(users.getLocalPort(), message);
			}
		} else {
			String roomNameSender = ChatServer.connectionUsers
					.getChatRoomName(socket.getPort());

			Set<Users> connectUser = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Iterator<Users> i = connectUser.iterator(); i.hasNext();) {
				Users users = i.next();
				if (users.getRoomName().equals(roomNameSender) == true) {
					sendMessageToChoosen(users.getLocalPort(), message);
				}
			}
		}
	}

	public void run() {
		try {
			try {
				//if (socket.isClosed() == false) {
					input = new Scanner(socket.getInputStream());
					out = new PrintWriter(socket.getOutputStream());
				//}
				while (ChatServer.connectionUsers.getFlag() == true) {
					try {

						checkConnection();

						ChatServer.connectionUsers.printCurrentUsers();

						if (input.hasNext() == false) {
							return;
						}

						SupportMessages newMessage = message
								.makeDefinitionNews(input.nextLine());

						switch (newMessage.getTypeMessage()) {
						case 0:
							System.out.println(newMessage.getMessage()[0]);
							sendMessageToCorrectRoom(newMessage.getMessage()[0]);
							break;
						case 1:
						case 2:
						case 3:
							break;
						case 4:
							updateRoomInArray(newMessage.getMessage());
							ChatServer.connectionUsers.updateRoomsList();
							break;
						case 5:
							sendInvite(newMessage.getMessage());
							break;
						case 6:
							sendPrivateMessage(newMessage.getMessage());
							break;
						case 7:
							System.out.println("LocalPort to remove: "
									+ newMessage.getMessage()[0]);
							ChatServer.connectionUsers.removeUser(newMessage
									.getMessage()[0]);
							break;
						case 9:
							shutDownServer(convertFromString(newMessage
									.getMessage()[0]));
							// disconnectuj
							ChatServer.allUsers.saveAllUsers();
							ChatServer.server.close();
							return;
						case 10:
							checkExistsRoom(newMessage.getMessage());
							break;
						default:
							break;
						}

						System.out.println("Client said: " + newMessage
								+ " Client's localPort: " + socket.getPort());

					} catch (Exception e) {
						ChatServer.logs.addError("Exception: "
								+ e.getStackTrace());
						e.printStackTrace();
						try {
							Thread.sleep(2);
						} catch (InterruptedException f) {
							ChatServer.logs.addError("InterruptedException: "
									+ f.getStackTrace());
							f.printStackTrace();
						}
					}

				}
			} finally {
				if (socket != null) {
					socket.close();
				}
				//ChatServer.allUsers.saveAllUsers();
			//	ChatServer.server.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Wysyla wiadomosc do uzytkownika w zbiorze polaczonych uzytkownikow o
	 * odpowiednim porcie
	 * 
	 * @param localPort
	 *            port socketa uzytkownika do ktorego ma byc wyslana wiadomosc
	 * @param message
	 *            tresc wiadomosci
	 * @throws IOException
	 */
	private static void sendMessageToChoosen(int localPort, String message)
			throws IOException {
		try {
			Set<Users> connectUser = ChatServer.connectionUsers
					.getAllConnectedUsers();

			for (Users user : connectUser) {
				if (user.getLocalPort() == localPort) {
					Socket tmpSocket = user.getSocket();
					PrintWriter tmpOut = new PrintWriter(
							tmpSocket.getOutputStream());
					tmpOut.println(message);
					tmpOut.flush();
					System.out.println("Send to: "
							+ tmpSocket.getLocalAddress().getHostName());
					break;
				}
			}

		} catch (SocketException e) {
			ChatServer.logs.addError("Socket Exception" + e.getStackTrace());
			e.printStackTrace();
		}
	}

}