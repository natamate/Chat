package main.java.pl.edu.agh.kis.interfaces;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Set;

import main.java.pl.edu.agh.kis.Users;


/**
 * Interfejs obslugujacy przechowywanie uzytkownikow w pliku
 * 
 * @author N.Materek
 * 
 */
public interface UsersDatabase {

	/**
	 * Zapisanie zbioru uzytkownikow do pliku
	 * 
	 * @param allUser
	 *            zior uzytkownikow
	 */
	void writeToFile(Set<Users> allUser) throws IOException, FileNotFoundException;

	/**
	 * Zwraca zbior wszystkich uzytkownikow zapisanych w pliku
	 * 
	 * @return zbior uzytkownikow
	 */
	Set<Users> readFromFile() throws IOException, FileNotFoundException;

	/**
	 * Ustawia sciezke do pliku w ktorym beda przechowywane dane
	 * 
	 * @param newPath
	 *            sciezka do pliku
	 */
	void setPath(String newPath) throws IOException;

	/**
	 * Zwraca sciezke do pliku w ktorym beda przechowywane dane
	 * 
	 * @return sciezka do pliku
	 */
	String getActualPath();
}
