package main.java.pl.edu.agh.kis.gui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

/**
 * Klasa obslugujaca zdarzenie nacisniecia przycisku CHOOSE, czyli wyslanie
 * wiadomosci prywatnej
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class SendPrivateMessages implements ButtonAction {

	private static JFrame mainWindow;
	private static JButton buttonSend;
	private static JTextArea textAreaMessage;
	private static JScrollPane scrollPanelConversation;

	/**
	 * Obsluga zdarzenia przycisku,
	 * Budowa okno napisania i wyslania wiadomosci prywatnej,
	 * Obsluguje akcje wcisniecia przycisku SEND Dodaje wiadomosc do wyslania do
	 * odpowiedniego uzytkownika w zbiorze wszytskich uzytkownikow, wysyla
	 * odpowiedni komunikat o wiadomosci
	 */
	public void actionButton() {
		buildMainWindow();
		mainWindowAction();
	}

	private static void buildMainWindow() {
		mainWindow = new JFrame();
		buttonSend = new JButton("SEND");
		textAreaMessage = new JTextArea();
		scrollPanelConversation = new JScrollPane();
		
		mainWindow.setTitle("New private messages");

		mainWindow.setSize(320, 200);
		mainWindow.setBackground(new java.awt.Color(255, 255, 255));
		mainWindow.setLocation(220, 180);
		mainWindow.setResizable(false);
		configureMainWindow();
		mainWindow.setVisible(true);
	}

	private static void configureMainWindow() {
		mainWindow.getContentPane().setLayout(null);

		textAreaMessage.setColumns(20);
		textAreaMessage.setFont(new java.awt.Font("Tahoma", 0, 12));
		textAreaMessage.setForeground(new java.awt.Color(0, 0, 255));
		textAreaMessage.setLineWrap(true);
		textAreaMessage.setRows(5);
		textAreaMessage.setEditable(true);

		scrollPanelConversation
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanelConversation
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPanelConversation.setViewportView(textAreaMessage);
		mainWindow.getContentPane().add(scrollPanelConversation);
		scrollPanelConversation.setBounds(10, 10, 295, 120);

		buttonSend.setBackground(new java.awt.Color(0, 0, 255));
		buttonSend.setForeground(new java.awt.Color(255, 255, 255));

		mainWindow.getContentPane().add(buttonSend);
		buttonSend.setBounds(120, 140, 81, 25);

		textAreaMessage.setVisible(true);
		buttonSend.setVisible(true);
		buttonSend.setEnabled(true);
	}

	private static void mainWindowAction() {
		buttonSend.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				ChatClientGUI.sendPrivateMessage(
						(String) ChatClientGUI.listOnline.getSelectedUsers(),
						textAreaMessage.getText());
				mainWindow.setVisible(false);
				textAreaMessage.setText("");
			}
		}

		);
	}

}
