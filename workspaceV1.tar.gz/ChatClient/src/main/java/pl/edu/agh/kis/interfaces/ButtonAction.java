package main.java.pl.edu.agh.kis.interfaces;

//import pl.edu.agh.kis.ChatClientGUI;

/**
 * Interfejs udostepnia metode akcji na klikniecie przycisku
 * @author N.Materek
 * @see ChatClientGUI
 */
public interface ButtonAction {
	/**
	 * Obsluguje akcje wcisniecia przycisku
	 */
	void actionButton();
}
