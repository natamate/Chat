package main.java.pl.edu.agh.kis.gui;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import javax.swing.JList;
import javax.swing.ListModel;

import main.java.pl.edu.agh.kis.interfaces.ListContent;

/**
 * Klasa generujaca zawartosc listy uzytkownikow ktorzy sa w pokoju z danym
 * uzytkownikiem
 * 
 * @author N.Materek
 * @see ListContent
 * 
 */
public class ListUsersInRoomGUI implements ListContent {

	/**
	 * zawartosc listy
	 */
	private static JList listUsersInTheSameRoom = new JList();

	private static Map<String, String> currentAllUser;

	private ArrayList<String> updateList(String userName, String chatRoomName) {
		
		ArrayList<String> usersInTheSameRoom = new ArrayList<>();

		for (Map.Entry<String, String> entry : currentAllUser.entrySet()) {
			if (entry.getValue().equals(chatRoomName) == true
					&& entry.getKey().equals(userName) == false
					&& entry.getKey().equals("root") == false) {
				usersInTheSameRoom.add(entry.getKey());
			}
		}

		System.out.println("ARRAY");

		return usersInTheSameRoom;
	}

	/**
	 * @return zwraca referencje do JList
	 */
	@Override
	public JList getList() {
		return listUsersInTheSameRoom;
	}

	/**
	 * Aktualizuje liste uzytkownikow ktorzy sa w jednym pokoju
	 * 
	 * @param contentArray
	 *            tablica z nazwa uzytkownika i pokojem w ktorym jest dla
	 *            ktorego generowana jest lista
	 * @param currentAllUsers
	 *            mapa wszytskich uzytkownikow klucz to nazwa uzytkownika a
	 *            wartosc to jego pokoj
	 */
	@Override
	public void setList(String[] contentArray,
			Map<String, String> currentAllUsers) {
		currentAllUser = currentAllUsers;

		ArrayList<String> usersInTheSameRoom = updateList(contentArray[0],
				contentArray[1]);
		for (String s : usersInTheSameRoom) {
			System.out.println("S: " + s);
		}
		if (usersInTheSameRoom.isEmpty() == false) {
			listUsersInTheSameRoom.setListData(usersInTheSameRoom.toArray());
		}
	}

	@Override
	public String getSelectedUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Zwraca liste uzytkownikow ktorzy sa na liscie
	 * 
	 * @return selections lista uzytkownikow zawartych w listUsersInTheSameRoom
	 */
	@Override
	public String[] getListContent() {
		ListModel model = listUsersInTheSameRoom.getModel();
		String[] selections = new String[model.getSize()];
		String userNameCurrent;

		for (int i = 0; i < model.getSize(); i++) {
			userNameCurrent = (String) model.getElementAt(i);
			selections[i] = userNameCurrent;
		}
		return selections;

	}

}
