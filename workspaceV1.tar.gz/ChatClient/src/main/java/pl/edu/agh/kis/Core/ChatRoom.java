package main.java.pl.edu.agh.kis.Core;

import java.io.Serializable;

/**
 * Klasa opisujaca pokoj czatu roomName - nazwa pokoju available - dostepnosc
 * pokoju (0 - publiczny, rozny od 0 prywatny)
 * 
 * @author N.Materek
 * @see Serializable
 */
public class ChatRoom implements Serializable {

	private int available = 0;
	private String roomName = "public";

	public ChatRoom(String roomName) {
		this.roomName = roomName;
	}

	public ChatRoom(int available, String roomName) {
		this(roomName);
		this.available = available;
	}

	public ChatRoom(String available, String roomName) {
		this(roomName);
		if (available.equals("public") == true || available.equals("0") == true) {
			this.available = 0;
		} else {
			this.available = 1;
		}
	}

	public String getRoomName() {
		return roomName;
	}

	public int getAvailable() {
		return available;
	}

	
	public void setRoomName(String name, int available) {
		roomName = name;
		this.available = available;
	}

	@Override
	public String toString() {
		return "RoomName: " + roomName + " avail.: " + getAvailable();
	}

}
