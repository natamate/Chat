package main.java.pl.edu.agh.kis.interfaces;

import java.util.Map;
import java.util.Set;

import javax.swing.JList;

import main.java.pl.edu.agh.kis.Core.Users;

/**
 * Udostepnia metody pozwalajace na ustawianie danych w liscie oraz otrzymywanie
 * aktualnej zawartosci listy
 * 
 * @author N.Materek
 * 
 */
public interface ListContent {
	/**
	 * @return zwraca referencje do JList
	 */
	JList getList();

	/**
	 * Aktualizuje liste wszystkich uzytkownikow i ikony dla polaczonych
	 * uzytkownikow
	 * 
	 * @param currentConnectNameUsers
	 *            tablica aktualnie polaczonych uzytkownikow
	 * @param nameUsersWithRoom
	 *            mapa uzytkownikow, gdzie klucz - nazwa uzytkownika, value -
	 *            nazwa pokoju
	 */
	void setList(String[] contentArray, Map<String, String> nameUsersWithRoom);

	/**
	 * @return zaznaczona wartosc na liscie
	 */
	String getSelectedUsers();

	/**
	 * Zwraca liste uzytkownikow ktorzy sa na liscie oprocz uzytkownika ktory
	 * aktualnie jest zalogowany w oknie
	 * 
	 * @return selections lista uzytkownikow zawartych z listAllUsers
	 */
	String[] getListContent();
}
