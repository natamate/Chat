package main.java.pl.edu.agh.kis.gui;

import javax.swing.JOptionPane;

import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

/**
 * Generuje akcje przycisku Help
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class HelpWindowGUI implements ButtonAction{
	public void actionButton(){
		StringBuilder sb = new StringBuilder();
		sb.append("Aby polaczyc sie z czatem wcisnij CONNECT i wpisz swoja nazwe uzytkownika.");
		sb.append("\n");
		sb.append("Domyslnie jestes w pokoju w publicznym, wszyscy ktorzy tez sa w pokoju publicznym widza twoje wiadomosci");
		sb.append("\n");
		sb.append("Mozesz utworzyc swoj wlasny pokoj klikajac na CREATEROOM");
		sb.append("\n");
		sb.append("Aby zaprosic kogos do pokoju kliknij INVITE");
		sb.append("\n");
		sb.append("W kazdej chwili mozesz opuscic pokoj klikajac EXIT");
		sb.append("\n");
		sb.append("Mozesz dolaczyc do publicznego pokoju klikajac na pokoj na liscie AVAILABLEROOMS i wciskajac JOIN");
		sb.append("\n");
		sb.append("Mozesz wyslac wiadomosc prwatna dla uzytkownika wybierajac uzytkownika z listy uzytkownikow i klikajac PRIV");
		sb.append("\n");
		sb.append("Aby sie rozlaczyc kliknij DISCONNECT");
		sb.append("\n");
		sb.append("Jesli masz problemy sprobuj uruchomic ponownie aplikacje i polacz sie jeszcze raz");
		JOptionPane.showMessageDialog(null, sb.toString());
	}
}
