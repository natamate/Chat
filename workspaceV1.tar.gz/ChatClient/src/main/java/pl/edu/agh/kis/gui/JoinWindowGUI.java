package main.java.pl.edu.agh.kis.gui;

import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

/**
 * Klasa obslugujaca zdarzenie dolaczenia do pokoju publicznego
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class JoinWindowGUI implements ButtonAction {

	/**
	 * Po wcisnieciu przycisku klient jest dolaczany do wybranego pokoju z listy
	 * pokoi, inicjalizuje dostepnosc odpowiednich przyciskow
	 */
	public void actionButton() {
		CreateRoomWindowGUI.joinToRoom("0",
				(String) ChatClientGUI.getSelectedRoomWithList());
		ChatClientGUI.initializeButtonAfterCreateRoom();
	}

}
