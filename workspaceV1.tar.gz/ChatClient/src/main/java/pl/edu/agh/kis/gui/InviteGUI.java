package main.java.pl.edu.agh.kis.gui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import main.java.pl.edu.agh.kis.interfaces.AppearanceMessages;
import main.java.pl.edu.agh.kis.Core.*;
/**
 * Klasa generujaca okno wyslania zaproszenia do pokoju
 * 
 * @see AppearanceMessages
 * @author N.Materek
 * 
 */
public class InviteGUI implements AppearanceMessages {

	private static JFrame mainWindow = new JFrame();
	private static JButton buttonYes = new JButton("YES");
	private static JButton buttonNo = new JButton("NO");
	private static JTextArea textAreadInvitation = new JTextArea();
	private static ChatRoom newChatRoom;

	/**
	 * Ustawia zaproszenie z odpowiednia nazwa uzytkownika zapraszajacego i
	 * nazwa pokoju pokoju
	 * 
	 * @param nameSender
	 *            port uzytkownika wysylajacego zaproszenie
	 * @param nameReceiver
	 *            port uzytkownika ktory ma otrzymac wiadomosc
	 * @param nameChatRoom
	 *            nazwa pokoju do ktorego zostal zaproszony uzytkownik
	 */
	public void sendMessage(String nameSender, String nameReceiver,
			String nameChatRoom) {
		buildMainWindow();

		textAreadInvitation.setText("Hey: " + nameReceiver + "\n The user: "
				+ nameSender + " sent you the invitation to room: " + "\n"
				+ newChatRoom.getRoomName() + "\n"
				+ "Will you join to room? \n");

	}

	private static void buildMainWindow() {
		mainWindow.setTitle("You have a new invitation");

		mainWindow.setSize(420, 160);
		mainWindow.setBackground(new java.awt.Color(255, 255, 255));
		mainWindow.setLocation(220, 180);
		mainWindow.setResizable(false);
		configureMainWindow();
		mainWindowAction();
		mainWindow.setVisible(true);
	}

	private static void configureMainWindow() {
		mainWindow.getContentPane().setLayout(null);

		textAreadInvitation.setForeground(new java.awt.Color(0, 0, 255));
		textAreadInvitation.requestFocus();
		mainWindow.getContentPane().add(textAreadInvitation);
		textAreadInvitation.setBounds(10, 10, 400, 80);
		textAreadInvitation.setFont(new java.awt.Font("Tahoma", 0, 12));

		buttonYes.setBackground(new java.awt.Color(0, 0, 255));
		buttonYes.setForeground(new java.awt.Color(255, 255, 255));

		mainWindow.getContentPane().add(buttonYes);
		buttonYes.setBounds(100, 100, 81, 25);

		buttonNo.setBackground(new java.awt.Color(0, 0, 255));
		buttonNo.setForeground(new java.awt.Color(255, 255, 255));

		mainWindow.getContentPane().add(buttonNo);
		buttonNo.setBounds(240, 100, 81, 25);

		textAreadInvitation.setVisible(true);
		buttonNo.setVisible(true);
		buttonYes.setVisible(true);
		buttonNo.setEnabled(true);
		buttonYes.setEnabled(true);
	}

	private static void mainWindowAction() {
		buttonYes.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				ChatClientGUI.initializeButtonAfterCreateRoom();
				CreateRoomWindowGUI.joinToRoom(newChatRoom.getAvailable() + "",
						newChatRoom.getRoomName());
				mainWindow.setVisible(false);
			}
		}

		);

		buttonNo.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				mainWindow.setVisible(false);
			}
		}

		);

	}

}
