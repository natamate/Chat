package main.java.pl.edu.agh.kis.gui;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import main.java.pl.edu.agh.kis.core.*;
import main.java.pl.edu.agh.kis.interfaces.ButtonAction;
import main.java.pl.edu.agh.kis.interfaces.Client;
import main.java.pl.edu.agh.kis.interfaces.ListContent;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

/**
 * Klasa generujaca wyglad okna czatu oraz interakcje z uzytkownikiem czatu
 * 
 * @see Client
 * @see ButtonAction
 * @author N.Materek
 * 
 */
public class ChatClientGUI {

	private static Client chatClient;
	private static String userName = "Anonymous";
	private static String password = "nothing";
	private static ChatRoom chatRoom = new ChatRoom(0, "public");

	private static ButtonAction exit = new ExitRoomWindowGui();
	private static ButtonAction invite = new InviteToRoomWindowGui();
	private static ButtonAction connect = new ConnectWindowGUI();
	private static ButtonAction join = new JoinWindowGUI();
	private static ButtonAction create = new CreateRoomWindowGUI();
	private static ButtonAction sendPrivate = new SendPrivateMessages();
	private static ButtonAction about = new AboutWindowGUI();
	private static ButtonAction help = new HelpWindowGUI();
	private static ButtonAction shutDown = new ShutDownAction();

	private static JFrame mainWindow = new JFrame();
	private static JButton buttonAbout = new JButton();
	private static JButton buttonConnect = new JButton();
	private static JButton buttonDisconnect = new JButton();
	private static JButton buttonHelp = new JButton();
	private static JButton buttonSend = new JButton();

	private static JButton buttonCreateRoom = new JButton();
	private static JButton buttonInvite = new JButton();
	private static JButton buttonExit = new JButton();
	private static JButton buttonJoin = new JButton();
	private static JButton buttonSendPrivateMessage = new JButton();

	private static JButton buttonShutDown = new JButton();

	private static JLabel labelMessage = new JLabel("Message: ");
	private static JTextField textFieldMessage = new JTextField(20);
	private static JLabel labelConversation = new JLabel();
	private static JTextArea textAreaConversation = new JTextArea();
	private static JScrollPane scrollPanelConversation = new JScrollPane();

	private static JLabel labelOnline = new JLabel();

	public static ListContent listOnline = new ListOnlineGUI();
	private static ListContent listInTheRoom = new ListUsersInRoomGUI();

	private static JScrollPane scrollPanelOnline = new JScrollPane();

	private static JLabel labelLoggedInAs = new JLabel();
	private static JLabel labelLoggedInAsBox = new JLabel();

	private static JLabel labelExistInRoom = new JLabel();
	private static JLabel labelExistInRoomAsBox = new JLabel();

	private static JLabel labelAvailableRoom = new JLabel();
	private static JList listAvailableRoom = new JList();

	private static JLabel labelUsersInRoom = new JLabel();
	private static JList listUsersInRoom = new JList();
	private static JScrollPane scrollPanelUsersInRoom = new JScrollPane();

	private static JScrollPane scrollPanelAvailableRoom = new JScrollPane();

	public static void main(String[] args) {
		buildMainWindow();
		initialize();
	}

	/**
	 * Ustawia etykiete zalogowany jako na odpowiednia nazwe uzytkownika
	 */
	public static void setLabelLoggedInAsBox() {
		labelLoggedInAsBox.setText(ChatClientGUI.userName);
	}

	/**
	 * Zwraca nazwe uzytkownika ustawiono w etykiecie zalogowany jako
	 * 
	 * @return nazwa uzytkownika aktualnie zalogowanego
	 */
	public static String getLabelLoggedInAsBox() {
		return labelLoggedInAsBox.getText();
	}

	/**
	 * Ustawia etykiete odpowiadajaca za aktualny pokoj uzytkownika na pokoj w
	 * ktorym uzytkownik aktualnie przebywa
	 */
	public static void setLabelExistInRoomAsBox(
			Map<String, String> currentAllUsers) {
		ChatClientGUI.chatRoom = new ChatRoom(currentAllUsers.get(userName));
		labelExistInRoomAsBox.setText(ChatClientGUI.chatRoom.getRoomName());
		if (labelExistInRoomAsBox.getText().equals("public") == false) {
			initializeButtonAfterCreateRoom();
		}
		setListUsersInRoom(currentAllUsers);
	}

	/**
	 * Aktualizuje lsite uzytkownikow przebywajacych w tym samym pokoju
	 * 
	 * @param currentAllUsers
	 *            mapa wszystkich uzytkownikow gdzie klucz to nazwa uzytkownika
	 *            a wartosc nazwa pokoju w ktorym jest uzytkownik
	 */
	public static void setListUsersInRoom(Map<String, String> currentAllUsers) {
		String[] content = { userName, chatRoom.getRoomName() };
		listInTheRoom.setList(content, currentAllUsers);
		listUsersInRoom.setListData(listInTheRoom.getListContent());
	}

	/**
	 * Zwraca zawartosc listy uzytkownikow ktorzy sa w tym samym pokoju co
	 * zalogowany uzytkownik
	 * 
	 * @return ArrayList<String> lista uzytkownik w tym samym pokoju co
	 *         zalogowany
	 */
	public static ArrayList<String> getListUsersInRoom() {
		ListModel model = listUsersInRoom.getModel();
		ArrayList<String> contentList = new ArrayList<>();
		String userNameCurrent;

		for (int i = 0; i < model.getSize(); i++) {
			userNameCurrent = (String) model.getElementAt(i);
			contentList.add(userNameCurrent);
		}
		return contentList;
	}

	/**
	 * Zwraca nazwe pokoju uzytkownika ustawiona w etykiecie odpowiadajacej za
	 * pokoj
	 * 
	 * @return nazwa pokoju w ktorym aktualnie jest uzytkownik
	 */
	public static String getLabelExistInRoomAsBox() {
		return labelExistInRoomAsBox.getText();
	}

	/**
	 * Ustawia nazwe uzytkownika do ktorego nalezy okno
	 * 
	 * @param newUsername
	 *            nazwa uzytkownika
	 */
	public static void setUserName(String newUsername) {
		userName = newUsername;
	}

	/**
	 * Zwraca nazwe uzytkownika do ktorego nalezy okno
	 * 
	 * @return nazwa uzytkownika
	 */
	public static String getUserName() {
		return userName;
	}

	/**
	 * Ustawia haslo uzytkownika do ktorego nalezy okno
	 * 
	 * @param newPassword
	 *            halo uzytkownika
	 */
	public static void setPassword(String newPassword) {
		password = newPassword;
	}

	/**
	 * Zwraca haslo uzytkownika do ktorego nalezy okno
	 * 
	 * @return haslo uzytkownika
	 */
	public static String getPassword() {
		return password;
	}

	/**
	 * Ustawia tytul okna z nazwa uzytkownika do ktorego aktualnie nalezy okno
	 */
	public static void setMainWindowTitle() {
		ChatClientGUI.mainWindow.setTitle(ChatClientGUI.userName
				+ "'s chat box");
	}

	/**
	 * Ustawia pokoj uzytkownika do ktorego nalezy okno
	 * 
	 * @param currentChatRoom
	 *            pokoj w ktorym aktualnie przebywa uzytkownik
	 */
	public static void setChatRoom(ChatRoom currentChatRoom) {
		chatRoom = currentChatRoom;
	}

	/**
	 * Zwraca pokoj w ktorym aktualnie jest uzytkownik
	 * 
	 * @return aktualny pokoj
	 */
	public static ChatRoom getChatRoom() {
		return chatRoom;
	}

	/**
	 * Ustawia klienta w oknie
	 * 
	 * @param newChatClient
	 *            nowy klient
	 */
	public static void setChatClient(Client newChatClient) {
		chatClient = newChatClient;
	}

	/**
	 * Zwraca klienta ktory jest przypisany do okna
	 * 
	 * @return aktualny klient
	 */
	public static ChatClient getCurrentChatClient() {
		return (ChatClient) chatClient;
	}

	/**
	 * Zwraca uzytkownika do ktorego aktualnie nalezy okno
	 * 
	 * @return uzytkownika do ktorego aktualnie nalezy okno
	 */
	public static Users getCurrentUser() {
		return new Users(ChatClientGUI.chatClient.getSocket().getPort(),
				ChatClientGUI.userName, ChatClientGUI.password,
				ChatClientGUI.chatRoom);
	}

	/**
	 * Wysyla informacje o zmianie pokoju
	 */
	public static void sendInfoAboutNewRoom() {
		chatClient.sendInfoAboutRoom(chatRoom.getRoomName(),
				chatRoom.getAvailable(), userName);
	}

	/**
	 * Wysyla wiadomosc prywatna
	 * 
	 * @param nameReceiver
	 *            nazwa uzytkownika ktory ma otrzymac wiadomosc
	 * @param message
	 *            tresc wiadomosci
	 */
	public static void sendPrivateMessage(String nameReceiver, String message) {
		chatClient.sendPrivateMessage(getLabelLoggedInAsBox(), nameReceiver,
				message);
	}

	/**
	 * Wysyla zapytanie czy nazwa tworzonego pokoju jest juz zajeta
	 * 
	 * @param roomName
	 *            nazwa pokoju ktory uzytkownik chce utworzyc
	 * @param availableRoom
	 *            dostepnosc pokoju
	 */
	public static void sendQuestionAboutAvailableRoomName(String roomName,
			String availableRoom) {
		chatClient.sendQuestionAboutAvailableRoomName(new ChatRoom(
				availableRoom, roomName), getLabelLoggedInAsBox());
	}

	/**
	 * Zwraca zaznaczony pokoj z listy
	 * 
	 * @return nazwa zaznaczongo pokoju
	 */
	public static String getSelectedRoomWithList() {
		return (String) listAvailableRoom.getSelectedValue();
	}

	/**
	 * Ustawia nowa liste dostepnych pokoi
	 * 
	 * @param listAvailableRooms
	 *            aktualnie dostepne pokoje
	 */
	public static void setListAvailableRoom(String[] listAvailableRooms) {
		listAvailableRoom.setListData(listAvailableRooms);
	}

	/**
	 * Ustawia nowa liste dostepnych uzytkownikow
	 * 
	 * @param onlineUsers
	 *            aktualnie zalogowani uzytkownicy
	 */
	public static void setListOnlineUsers(String[] onlineUsers,
			Map<String, String> currentAllUsers) {
		listOnline.setList(onlineUsers, currentAllUsers);
	}

	/**
	 * Ustawia podana wiadomosc w oknie konwersacji
	 * 
	 * @param message
	 *            wiadomosc do wyswietlenia
	 */
	public static void addToAreaTextConversation(String message) {
		textAreaConversation.append(message);
	}

	/**
	 * Ustawia podana wiadomosc w oknie wysylanie wiadomosci
	 * 
	 * @param message
	 *            wiadomosc do wyswietlenia
	 */
	public static void setTextFieldMessage(String message) {
		textFieldMessage.setText(message);
	}

	/**
	 * Ustawia dostepnosc przyciskow po pomyslnym polaczeniu
	 */
	public static void initializeButtonAfterConnect() {
		buttonSend.setEnabled(true);
		buttonDisconnect.setEnabled(true);
		buttonCreateRoom.setEnabled(true);
		buttonConnect.setEnabled(false);
		if (userName.equals("root") == true) {
			buttonShutDown.setEnabled(true);
			buttonShutDown.setVisible(true);
		} else {
			buttonShutDown.setVisible(false);
			buttonShutDown.setEnabled(false);
		}
		mainWindow.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}

	/**
	 * Ustawia dostepnosc przyciskow po akcji dolaczenia do pokoju (utworzenia
	 * pokoju, dolaczenia, lub akceptowania zaproszenia do pokoju)
	 */
	public static void initializeButtonAfterCreateRoom() {
		buttonCreateRoom.setEnabled(false);
		buttonExit.setEnabled(true);
		buttonInvite.setEnabled(true);
	}

	/**
	 * Ustawia dostepnosc przyciskow po opuszczeniu pokoju
	 */
	public static void initializeButtonAfterQuitRoom() {
		buttonCreateRoom.setEnabled(true);
		buttonExit.setEnabled(false);
		buttonInvite.setEnabled(false);
	}

	/**
	 * Ustawia dostepnosc przycisku invite
	 */
	public static void initializeInvite() {
		buttonInvite.setEnabled(true);
	}

	/**
	 * Ustawia dostepnosc odpowiednich przyciskow po wlaczeniu aplikacji
	 */
	private static void initialize() {
		buttonSend.setEnabled(false);
		buttonConnect.setEnabled(true);
		buttonDisconnect.setEnabled(false);
		buttonExit.setEnabled(false);
		buttonInvite.setEnabled(false);
		buttonCreateRoom.setEnabled(false);
		buttonJoin.setEnabled(false);
		buttonSendPrivateMessage.setEnabled(false);
		buttonShutDown.setEnabled(false);
		buttonShutDown.setVisible(false);
	}

	/**
	 * Ustawia wyglad, rozklad, rozmiar komponentow w oknie glownym
	 */
	private static void buildMainWindow() {
		mainWindow.setTitle(userName + "'s chat box");
	//	mainWindow.setSize(450, 500);
		mainWindow.setLocation(220, 180);
		mainWindow.setResizable(false);
		configureMainWindow();
		mainWindowAction();
		mainWindow.setVisible(true);
	}

	private static void configureMainWindow() {
		mainWindow.setBackground(new java.awt.Color(255, 255, 255));
		mainWindow.setSize(810, 340);
	
		mainWindow.getContentPane().setLayout(null);

		buttonSend.setBackground(new java.awt.Color(0, 0, 255));
		buttonSend.setForeground(new java.awt.Color(255, 255, 255));
		buttonSend.setText("SEND");

		mainWindow.getContentPane().add(buttonSend);
		buttonSend.setBounds(250, 40, 81, 25);

		buttonDisconnect.setBackground(new java.awt.Color(0, 0, 255));
		buttonDisconnect.setForeground(new java.awt.Color(255, 255, 255));
		buttonDisconnect.setText("DISCONNECT");
		mainWindow.getContentPane().add(buttonDisconnect);
		buttonDisconnect.setBounds(10, 40, 110, 25);

		buttonConnect.setBackground(new java.awt.Color(0, 0, 255));
		buttonConnect.setForeground(new java.awt.Color(255, 255, 255));
		buttonConnect.setText("CONNECT");
		mainWindow.getContentPane().add(buttonConnect);
		buttonConnect.setBounds(130, 40, 110, 25);

		buttonCreateRoom.setBackground(new java.awt.Color(0, 0, 255));
		buttonCreateRoom.setForeground(new java.awt.Color(255, 255, 255));
		buttonCreateRoom.setText("CREATE ROOM");
		mainWindow.getContentPane().add(buttonCreateRoom);
		buttonCreateRoom.setBounds(660, 10, 135, 25);

		buttonInvite.setBackground(new java.awt.Color(0, 0, 255));
		buttonInvite.setForeground(new java.awt.Color(255, 255, 255));
		buttonInvite.setText("INVITE");
		mainWindow.getContentPane().add(buttonInvite);

		buttonInvite.setBounds(660, 40, 135, 25);

		buttonExit.setBackground(new java.awt.Color(0, 0, 255));
		buttonExit.setForeground(new java.awt.Color(255, 255, 255));
		buttonExit.setText("LEAVE ROOM");
		mainWindow.getContentPane().add(buttonExit);

		buttonExit.setBounds(500, 40, 150, 25);

		buttonHelp.setBackground(new java.awt.Color(0, 0, 255));
		buttonHelp.setForeground(new java.awt.Color(255, 255, 255));
		buttonHelp.setText("HELP");
		mainWindow.getContentPane().add(buttonHelp);
		buttonHelp.setBounds(420, 40, 70, 25);

		buttonAbout.setBackground(new java.awt.Color(0, 0, 255));
		buttonAbout.setForeground(new java.awt.Color(255, 255, 255));
		buttonAbout.setText("ABOUT");
		mainWindow.getContentPane().add(buttonAbout);
		buttonAbout.setBounds(340, 40, 75, 25);

		buttonJoin.setBackground(new java.awt.Color(0, 0, 255));
		buttonJoin.setForeground(new java.awt.Color(255, 255, 255));
		buttonJoin.setText("JOIN");
		mainWindow.getContentPane().add(buttonJoin);
		buttonJoin.setBounds(660, 280, 130, 25);

		labelMessage.setText("Message: ");
		mainWindow.getContentPane().add(labelMessage);
		labelMessage.setBounds(10, 10, 60, 20);

		textFieldMessage.setForeground(new java.awt.Color(0, 0, 255));
		textFieldMessage.requestFocus();
		mainWindow.getContentPane().add(textFieldMessage);
		textFieldMessage.setBounds(70, 4, 260, 30);

		labelConversation.setHorizontalAlignment(SwingConstants.CENTER);
		labelConversation.setText("Conversation");
		mainWindow.getContentPane().add(labelConversation);
		labelConversation.setBounds(100, 70, 140, 16);

		textAreaConversation.setColumns(20);
		textAreaConversation.setFont(new java.awt.Font("Tahoma", 0, 12));
		textAreaConversation.setForeground(new java.awt.Color(0, 0, 255));
		textAreaConversation.setLineWrap(true);
		textAreaConversation.setRows(5);
		textAreaConversation.setEditable(false);

		scrollPanelConversation
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanelConversation
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPanelConversation.setViewportView(textAreaConversation);
		mainWindow.getContentPane().add(scrollPanelConversation);
		scrollPanelConversation.setBounds(10, 90, 320, 180);

		labelOnline.setHorizontalAlignment(SwingConstants.CENTER);
		labelOnline.setText("Currently online ");
		labelOnline.setToolTipText(" ");
		mainWindow.getContentPane().add(labelOnline);
		labelOnline.setBounds(350, 70, 130, 16);

		buttonSendPrivateMessage.setBackground(new java.awt.Color(0, 0, 255));
		buttonSendPrivateMessage
				.setForeground(new java.awt.Color(255, 255, 255));
		buttonSendPrivateMessage.setText("PRIV");
		mainWindow.getContentPane().add(buttonSendPrivateMessage);
		buttonSendPrivateMessage.setBounds(340, 280, 150, 25);

		scrollPanelOnline
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanelOnline
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPanelOnline.setViewportView(listOnline.getList());
		mainWindow.getContentPane().add(scrollPanelOnline);
		scrollPanelOnline.setBounds(340, 90, 150, 180);

		labelLoggedInAs.setFont(new java.awt.Font("Tahoma", 0, 12));
		labelLoggedInAs.setText("Currently logged in as ");
		mainWindow.getContentPane().add(labelLoggedInAs);
		labelLoggedInAs.setBounds(348, 0, 140, 15);

		labelLoggedInAsBox.setHorizontalAlignment(SwingConstants.CENTER);
		labelLoggedInAsBox.setFont(new java.awt.Font("Tahoma", 0, 12));
		labelLoggedInAsBox.setForeground(new java.awt.Color(255, 0, 0));
		labelLoggedInAsBox.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(0, 0, 0)));
		mainWindow.getContentPane().add(labelLoggedInAsBox);
		labelLoggedInAsBox.setBounds(340, 17, 150, 20);

		labelExistInRoom.setFont(new java.awt.Font("Tahoma", 0, 12));
		labelExistInRoom.setText("Currently is in room... ");
		mainWindow.getContentPane().add(labelExistInRoom);
		labelExistInRoom.setBounds(500, 0, 140, 15);

		labelExistInRoomAsBox.setHorizontalAlignment(SwingConstants.CENTER);
		labelExistInRoomAsBox.setFont(new java.awt.Font("Tahoma", 0, 12));
		labelExistInRoomAsBox.setForeground(new java.awt.Color(255, 0, 0));
		labelExistInRoomAsBox.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(0, 0, 0)));
		mainWindow.getContentPane().add(labelExistInRoomAsBox);
		labelExistInRoomAsBox.setBounds(500, 17, 150, 20);

		labelAvailableRoom.setHorizontalAlignment(SwingConstants.CENTER);
		labelAvailableRoom.setText("Available rooms ");
		labelAvailableRoom.setToolTipText(" ");
		mainWindow.getContentPane().add(labelAvailableRoom);
		// labelAvailableRoom.setBounds(500, 135, 130, 16);
		labelAvailableRoom.setBounds(660, 70, 130, 16);

		listAvailableRoom.setForeground(new java.awt.Color(0, 0, 255));

		scrollPanelAvailableRoom
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanelAvailableRoom
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPanelAvailableRoom.setViewportView(listAvailableRoom);
		mainWindow.getContentPane().add(scrollPanelAvailableRoom);
		scrollPanelAvailableRoom.setBounds(660, 91, 130, 180);

		labelUsersInRoom.setHorizontalAlignment(SwingConstants.CENTER);
		labelUsersInRoom.setText("Users of the room: ");
		labelUsersInRoom.setToolTipText(" ");
		mainWindow.getContentPane().add(labelUsersInRoom);
		labelUsersInRoom.setBounds(500, 70, 140, 16);

		listUsersInRoom.setForeground(new java.awt.Color(0, 0, 255));
		scrollPanelUsersInRoom
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanelUsersInRoom
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPanelUsersInRoom.setViewportView(listUsersInRoom);
		mainWindow.getContentPane().add(scrollPanelUsersInRoom);
		scrollPanelUsersInRoom.setBounds(500, 90, 150, 180);

		buttonShutDown.setBackground(new java.awt.Color(255, 0, 0));
		buttonShutDown.setForeground(new java.awt.Color(255, 255, 255));
		buttonShutDown.setText("SHUTDOWN");
		mainWindow.getContentPane().add(buttonShutDown);
		buttonShutDown.setBounds(80, 275, 150, 25);
	}

	/**
	 * Generuje wszystkie akcje potrzebne do interakcji z uzytkownikiem
	 */
	private static void mainWindowAction() {

		buttonSend.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				actionButtonSend();
			}
		}

		);

		buttonDisconnect.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				actionButtonDisconnect();
			}
		}

		);

		buttonConnect.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				connect.actionButton();
				// mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});

		buttonHelp.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				help.actionButton();
			}
		}

		);

		buttonAbout.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				about.actionButton();
			}
		}

		);

		buttonCreateRoom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				create.actionButton();
			}
		});

		buttonInvite.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				invite.actionButton();
			}
		});

		buttonExit.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				exit.actionButton();
			}
		});

		buttonJoin.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				join.actionButton();
			}
		});

		buttonSendPrivateMessage
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent event) {
						sendPrivate.actionButton();
					}
				});

		buttonShutDown.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				shutDown.actionButton();
			}
		});

		listAvailableRoom.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent event) {
				if (event.getValueIsAdjusting() == false
						&& listAvailableRoom.getSelectedIndex() >= 0) {
					String choose = (String) listAvailableRoom
							.getSelectedValue();
					if (choose.equals(getLabelExistInRoomAsBox()) == false) {
						buttonJoin.setEnabled(true);
					} else {
						buttonJoin.setEnabled(false);
					}
				}
			}
		});

		listOnline.getList().addListSelectionListener(
				new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent event) {
						if (event.getValueIsAdjusting() == false
								&& listOnline.getList().getSelectedIndex() >= 0) {
							String choose = (String) listOnline.getList()
									.getSelectedValue();
							if (choose.equals(getLabelLoggedInAsBox()) == false) {
								buttonSendPrivateMessage.setEnabled(true);
							} else {
								buttonSendPrivateMessage.setEnabled(false);
							}
						}
					}
				});

	}

	/**
	 * Metoda obsluguje akcje wcisniecia przycisku SEND
	 */
	public static void actionButtonSend() {
		if (textFieldMessage.getText().equals("") == false) {
			chatClient.sendMessage(textFieldMessage.getText());
			textFieldMessage.requestFocus();
		}
	}

	/**
	 * Metoda obsluguje akcje wcisniecia przycisku DISCONNECT
	 */
	public static void actionButtonDisconnect() {
		try {
			chatClient.disconnect();
		} catch (Exception e) {
			System.err.println(e);
			e.printStackTrace();
		}
	}

}
