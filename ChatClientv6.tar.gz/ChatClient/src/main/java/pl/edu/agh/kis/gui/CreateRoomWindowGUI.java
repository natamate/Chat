package main.java.pl.edu.agh.kis.gui;

import java.awt.Button;
import java.io.IOException;
import java.net.Socket;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;

import main.java.pl.edu.agh.kis.core.*;
import main.java.pl.edu.agh.kis.interfaces.ButtonAction;
/**
 * Klasa obsluguje zdarzenie wcisniecia przycisku CREATE ROOM oraz udostepnia
 * metode dodajaca uzytkownikow do pokoju
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class CreateRoomWindowGUI implements ButtonAction {

	private static JFrame makeRoomInWindow;
	private static JPanel panelCreateRoom;
	private static JComboBox<String> availableRoom;
	private static JTextField textFieldRoomNameBox;
	private static JButton buttonEnterRoom;

	/**
	 * Tworzy okno tworzenia pokoju, ustawia nazwy, wielkosci komponentow
	 */
	private static void buildCreateRoomInWidow() {
		makeRoomInWindow = new JFrame();
		textFieldRoomNameBox = new JTextField(20);
		buttonEnterRoom = new JButton("Enter");
		buttonEnterRoom.setBackground(new java.awt.Color(0, 0, 255));
		buttonEnterRoom.setForeground(new java.awt.Color(255, 255, 255));

		makeRoomInWindow.setTitle("What's name your room ? ");
		makeRoomInWindow.setSize(250, 120);
		makeRoomInWindow.setLocation(250, 200);
		makeRoomInWindow.setResizable(false);

		panelCreateRoom = new JPanel();
		panelCreateRoom.add(textFieldRoomNameBox);
		panelCreateRoom.add(buttonEnterRoom);

		String[] selectionsAvailable = { "public", "private" };
		availableRoom = new JComboBox<String>(selectionsAvailable);

		panelCreateRoom.add(availableRoom);

		makeRoomInWindow.add(panelCreateRoom);

		makeRoomInWindow.setVisible(true);
	}

	/**
	 * Obsluguje akcje wcisnienia przycisku create, Buduje okno tworzenia pokoju
	 * oraz obsluguje akcje dolaczenia do pokoju
	 */
	public void actionButton() {
		buildCreateRoomInWidow();
		makeRoomInAction();
	}

	private static void makeRoomInAction() {
		buttonEnterRoom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				actionButtonEnterRoom();
			}
		});
	}

	/**
	 * Metoda zmienia pokoj uzytkownika na podany jako argument, wysyla do
	 * serwera komunikat aby zaktualizowal aktualne pokoje
	 * 
	 * @param availableOfRoom
	 *            dostepnosc pokoju "0" lub "public" publiczny inne prywatny
	 * @param nameOfRoom
	 *            nazwa pokoju
	 */
	public static void joinToRoom(String availableOfRoom, String nameOfRoom) {
		ChatRoom newChatRoom = new ChatRoom(availableOfRoom, nameOfRoom);
		ChatClientGUI.setChatRoom(newChatRoom);
		ChatClientGUI.sendInfoAboutNewRoom();
	}

	/**
	 * metoda obslugujaca akcje wcisniecia przycisku, jesli nazwa pokoju jest
	 * zajeta zostanie zwrocony odpowiedni komunikat, jesli pokoj zostanie
	 * utworzony pomyslnie uzytkownik zostanie dolaczony do pokoju, nastapi
	 * inicjalizacja odpowiednich przycisku po stworzeniu pokoju
	 */
	private static void actionButtonEnterRoom() {

		if (textFieldRoomNameBox.getText().equals("") == false) {

				String available = (String) availableRoom.getSelectedItem();
				String nameRoom = textFieldRoomNameBox.getText().trim();
				
				ChatClientGUI.sendQuestionAboutAvailableRoomName(nameRoom, available);

				makeRoomInWindow.setVisible(false);

		} else {
			JOptionPane.showMessageDialog(null, "Please enter a room's name ");
		}
	}
	
}
