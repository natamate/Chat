package main.java.pl.edu.agh.kis.gui;

import java.io.IOException;

import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.ListModel;

import main.java.pl.edu.agh.kis.core.*;
import main.java.pl.edu.agh.kis.interfaces.*;
/**
 * Klasa generuje okienko logowania sie klienta
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 * 
 */
public class ConnectWindowGUI implements ButtonAction {

	private static JFrame logInWindow = new JFrame();
	private static JTextField textFieldUserNameBox = new JTextField(20);
	private static JPasswordField textFieldPasswordBox = new JPasswordField(20);
	private static JButton buttonEnter = new JButton("Enter");
	private static JLabel labelEnterUserName = new JLabel("Username: ");
	private static JLabel labelEnterPassword = new JLabel("Password: ");
	private static JPanel panelLogin = new JPanel();
	// private static JTextField port = new JTextField(20);
	private static JTextField host = new JTextField(20);
	// private static JLabel labelPort = new JLabel("Port: ");
	private static JLabel labelHost = new JLabel("Hostname: ");

	/**
	 * Obsluguje akcje wcisniecia przycisku connect, buduje okno logowania oraz
	 * obsluguje akcje logowania do czatu
	 */
	public void actionButton() {
		buildLogInWindow();
	}

	/**
	 * Buduje okienko logowania ustawiajac wszystkie komponenty na odpowiednim
	 * miejscu
	 */
	private void buildLogInWindow() {
		logInWindow.setTitle("What's your name ? ");
		logInWindow.setSize(350, 130);
		logInWindow.setLocation(250, 200);
		logInWindow.setResizable(false);
		panelLogin = new JPanel();
		// panelLogin.add(labelPort);
		// panelLogin.add(port);
		panelLogin.add(labelHost);
		panelLogin.add(host);
		panelLogin.add(labelEnterUserName);
		panelLogin.add(textFieldUserNameBox);
		panelLogin.add(labelEnterPassword);
		panelLogin.add(textFieldPasswordBox);

		buttonEnter.setBackground(new java.awt.Color(0, 0, 255));
		buttonEnter.setForeground(new java.awt.Color(255, 255, 255));

		panelLogin.add(buttonEnter);
		logInWindow.add(panelLogin);
		logInAction();
		logInWindow.setVisible(true);
	}

	private void logInAction() {
		buttonEnter.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				actionButtonEnter();
			}
		});
	}

	/**
	 * Metoda obsluguje zdarzenie wcisniecia przycisku, jesli uzytkownik nie
	 * wpisal nazwy uzytkownika ponownie jest wyswietlane okno logowania.
	 * Uzytkownik jest laczony z serwerem i dolaczane do odpowiedniego pokoju
	 * (jesli nie ma przypisanego zadnego pokoju jest to pokoj publiczny)
	 */
	private void actionButtonEnter() {

		if (textFieldUserNameBox.getText().equals("") == false
				&& textFieldPasswordBox.getText().equals("") == false) {

			ChatClientGUI.setUserName(textFieldUserNameBox.getText().trim());
			ChatClientGUI.setPassword(textFieldPasswordBox.getText().trim());
			ChatClientGUI.setLabelLoggedInAsBox();
			ChatClientGUI.setMainWindowTitle();

			logInWindow.setVisible(false);
			ChatClientGUI.initializeButtonAfterConnect();

			connect();

		} else {
			JOptionPane.showMessageDialog(null, "Please enter your data ");
		}
	}

	/**
	 * Laczy klienta z serwerem, dodaje go do listy wszystkich uzytkownikow
	 */
	private static void connect() {
		try {
			final String hostname;
			if (host.getText().equals("")){
				hostname = "localhost";
			}else{
				hostname = host.getText().trim();
			}
			final int port = 1027;

			// final String host = "localhost";
			Socket socket = new Socket(hostname, port);
			System.out.println("You connected to: " + hostname);
			ChatClientGUI.setChatClient(new ChatClient(socket));

			PrintWriter out = new PrintWriter(socket.getOutputStream());
			out.println(ChatClientGUI.getUserName() + ", "
					+ textFieldPasswordBox.getText());
			out.flush();

			Thread X = new Thread(ChatClientGUI.getCurrentChatClient());
			X.start();

		} catch (UnknownHostException e) {
			System.err.println(e);
			JOptionPane.showMessageDialog(null, "Unknown host ");
			System.exit(0);
		} catch (IOException e) {

			System.err.println(e);
			JOptionPane.showMessageDialog(null, "Server not responding ");
			System.exit(0);
		}
	}

}
