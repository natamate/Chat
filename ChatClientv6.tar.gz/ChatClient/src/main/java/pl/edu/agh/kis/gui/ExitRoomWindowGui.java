package main.java.pl.edu.agh.kis.gui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import main.java.pl.edu.agh.kis.core.*;
import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

/**
 * Klasa obslugujaca zdarzenie wyjscia z pokoju
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class ExitRoomWindowGui implements ButtonAction {

	/**
	 * Metoda ustawia pokoj uzytkownika na domyslny - public po jego wyjsciu z
	 * pokoju, inicjalizuje odpowiednie przyciski po opuszczeniu pokoju oraz
	 * wysyla komunikat do serwera aby zaaktualizowal pokoje.
	 */
	public void actionButton() {
		ChatRoom newChatRoom = new ChatRoom(0, "public");
		ChatClientGUI.setChatRoom(newChatRoom);

		ChatClientGUI.initializeButtonAfterQuitRoom();

		ChatClientGUI.sendInfoAboutNewRoom();

	}

}
