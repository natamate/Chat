package main.java.pl.edu.agh.kis.interfaces;

import main.java.pl.edu.agh.kis.core.DefinitionNews;

/**
 * Obsluguje zdefiniowanie typu wiadomosci wyslanej, zeby podjac wlasciwa akcje
 * 
 * @author N.Materek
 * 
 */
public interface SupportMessages {
	/**
	 * Zwraca wiadomosc z okreslonym typem MESSAGE(0), ADDUSER(1),
	 * ADDROOM(2), INVITES(3), INFROOM(4), SENDINVITE(5), PRIVMES( 6),
	 * DISCONNECT(7), DELIVERPRIV(8);
	 * @see Command
	 */
	public SupportMessages makeDefinitionNews(String inputMessage);
	
	/**
	 * Zwraca tresc wiadomosci
	 * 
	 * @return wlasciwa tresc
	 */
	public String[] getMessage();
	
	/**
	 * Zwraca typ wiadomosci
	 * 
	 * @return int typ
	 */
	public int getTypeMessage();
}
