package main.java.pl.edu.agh.kis.gui;

import java.awt.BorderLayout;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;

import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

import com.sun.org.apache.bcel.internal.generic.LSTORE;

/**
 * Generuje akcje przycisku Invite jesli jest dostepny
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class InviteToRoomWindowGui implements ButtonAction {

	private static JFrame inviteToRoom ;
	private static JPanel panelInviteToRoom;
	private static JButton buttonIvite;
	private static JList listAvailableUsers;
	private static JScrollPane scrollPanelAvailableUsers;
	
	private static void buildInviteWindow() {
		 inviteToRoom = new JFrame();
		 panelInviteToRoom = new JPanel();
		 buttonIvite = new JButton("Invite");
		 listAvailableUsers = new JList();
		
		inviteToRoom.setTitle("Who you want to invite? ");
		inviteToRoom.setSize(300, 220);
		inviteToRoom.setLocation(250, 200);
		inviteToRoom.setResizable(false);

		inviteToRoom.getContentPane().setLayout(null);

		String [] listAllUsers = ChatClientGUI.listOnline
				.getListContent();
		ArrayList<String> listUsersWhoAreInYourRoom = ChatClientGUI.getListUsersInRoom();
		ArrayList<String> usersToInvite = new ArrayList<>();
		
		for (String s : listAllUsers){
			if (listUsersWhoAreInYourRoom.contains(s) == false){
				usersToInvite.add(s);
			}
		}

		listAvailableUsers.setListData(usersToInvite.toArray());
		listAvailableUsers
				.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		scrollPanelAvailableUsers = new JScrollPane(listAvailableUsers);

		scrollPanelAvailableUsers
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanelAvailableUsers
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		inviteToRoom.getContentPane().add(scrollPanelAvailableUsers);
		scrollPanelAvailableUsers.setBounds(25, 10, 250, 150);

		buttonIvite.setBackground(new java.awt.Color(0, 0, 255));
		buttonIvite.setForeground(new java.awt.Color(255, 255, 255));
		inviteToRoom.getContentPane().add(buttonIvite);
		buttonIvite.setBounds(100, 165, 90, 25);

		inviteToRoom.setVisible(true);
	}

	/**
	 * Generuje okno pozwalajace zapraszac uzytkownikow, lista uzytkownikow do
	 * zaproszenia to wszyscy uzytkownicy. Obsluga zdarzenie wcisniecia
	 * przycisku
	 */
	public void actionButton() {
		buildInviteWindow();
		inviteToRoomInAction();
	}

	private static void inviteToRoomInAction() {
		buttonIvite.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				actionButtonInviteToRoom();
			}
		});
	}

	private static void actionButtonInviteToRoom() {
		if (listAvailableUsers.getSelectedValue() != null) {
			JOptionPane.showMessageDialog(null, "You choose:  "
					+ listAvailableUsers.getSelectedValue());
		} else {
			JOptionPane
					.showMessageDialog(null, "Do you want to invite anyone?");
		}
		ChatClientGUI.getCurrentChatClient().sendInvite(
				ChatClientGUI.getLabelLoggedInAsBox(),
				(String) listAvailableUsers.getSelectedValue(), ChatClientGUI.getLabelExistInRoomAsBox());
		inviteToRoom.setVisible(false);
	}
}
