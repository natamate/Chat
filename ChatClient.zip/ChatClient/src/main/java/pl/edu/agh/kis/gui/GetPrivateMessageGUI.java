package main.java.pl.edu.agh.kis.gui;

import java.util.Map;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import main.java.pl.edu.agh.kis.interfaces.AppearanceMessages;

/**
 * Klasa generuje okienko z otrzymana wiadomoscia prywatna
 * 
 * @author N.Materek
 * @see AppearanceMessages
 */
public class GetPrivateMessageGUI implements AppearanceMessages {
	private static JFrame mainWindow;
	private static JButton buttonOk;
	private static JTextArea textAreaMessage;
	private static JScrollPane scrollPanelConversation;

	/**
	 * Ustawienie glownego okna: skonfigurowanie ustawienia i wielkosci komponentow w glownym oknie.
	 * Pobiera wiadomosci dla uzytkownika ze zbioru wszystkich
	 * uzytkownikow i wypisuje je w widocznym oknie
	 * 
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 * @param nameReceiver
	 *            nazwa uzytkownika ktory jest odbiorca wiadomosci
	 */
	public void sendMessage(String nameSender, String nameReceiver, String message) {
		buildMainWindow();
		
			StringBuilder sb = new StringBuilder();
			
			sb.append("The new messages : " + "\n");

			sb.append(nameSender + ": " + message + "\n");
			
			textAreaMessage.setText(sb.toString());
	}

	private static void buildMainWindow() {
		mainWindow = new JFrame();
		buttonOk = new JButton("OK");
		buttonOk.setBackground(new java.awt.Color(0, 0, 255));
		buttonOk.setForeground(new java.awt.Color(255, 255, 255));
		
		textAreaMessage = new JTextArea();
		scrollPanelConversation = new JScrollPane();
		
		mainWindow.setTitle("Private messages");

		mainWindow.setSize(300, 220);
		mainWindow.setBackground(new java.awt.Color(255, 255, 255));
		mainWindow.setLocation(220, 180);
		mainWindow.setResizable(false);
		configureMainWindow();
		mainWindowAction();
		mainWindow.setVisible(true);
	}

	private static void configureMainWindow() {
		mainWindow.getContentPane().setLayout(null);

		textAreaMessage.setColumns(20);
		textAreaMessage.setFont(new java.awt.Font("Tahoma", 0, 12));
		textAreaMessage.setForeground(new java.awt.Color(0, 0, 255));
		textAreaMessage.setLineWrap(true);
		textAreaMessage.setRows(5);
		textAreaMessage.setEditable(false);
		textAreaMessage.setText("");

		scrollPanelConversation
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanelConversation
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPanelConversation.setViewportView(textAreaMessage);
		mainWindow.getContentPane().add(scrollPanelConversation);
		scrollPanelConversation.setBounds(15, 15, 280, 140);

		buttonOk.setBackground(new java.awt.Color(0, 0, 255));
		buttonOk.setForeground(new java.awt.Color(255, 255, 255));

		mainWindow.getContentPane().add(buttonOk);
		buttonOk.setBounds(90, 160, 120, 25);

		textAreaMessage.setVisible(true);
		buttonOk.setVisible(true);
		buttonOk.setEnabled(true);
	}

	private static void mainWindowAction() {
		buttonOk.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				mainWindow.setVisible(false);
			}
		}

		);
	}
}
