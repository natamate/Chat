package main.java.pl.edu.agh.kis.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import main.java.pl.edu.agh.kis.interfaces.ListContent;

/**
 * Klasa generujaca zawartosc listy uzytkownikow polaczonych
 * 
 * @author N.Materek
 * @see ListContent
 * 
 */
class ListOnlineGUI implements ListContent {

	/**
	 * Mapa generuje polaczenie uzytkownika z odpowiednim stanem: online lub
	 * offline
	 */
	private Map<String, ImageIcon> imageMap;

	/**
	 * zawartosc listy
	 */
	private static JList listAllUsers;

	/**
	 * Ustawia domyslnie wszystkich uzytkownikow jako niepolaczonych
	 */
	public ListOnlineGUI() {
		Map<String, String> userWithStatus = new HashMap<>();

		ArrayList<String> allUsers = new ArrayList<>();
		allUsers.add("not available");

		for (String name : allUsers) {
			userWithStatus.put(name, "Offline");
		}

		listAllUsers = new JList(allUsers.toArray());
		imageMap = createImageMap(userWithStatus);
		listAllUsers.setCellRenderer(new StatusListRendered());
	}

	/**
	 * @return zwraca referencje do JList
	 */
	public JList getList() {
		return listAllUsers;
	}

	/**
	 * Aktualizuje liste wszystkich uzytkownikow i ikony dla polaczonych
	 * uzytkownikow
	 * 
	 * @param currentConnectNameUsers
	 *            tablica aktualnie polaczonych uzytkownikow
	 * @param allUsers
	 *            zbior wszystkich uzytkownikow
	 */
	public void setList(String[] currentConnectNameUsers,
			Map<String, String> allUsers) {

		ArrayList<String> nameAllUsers = new ArrayList<>();
		for (Map.Entry<String, String> entry : allUsers.entrySet()) {
			nameAllUsers.add(entry.getKey());
		}

		listAllUsers.setListData(nameAllUsers.toArray());
		imageMap = createImageMap(setIcon(currentConnectNameUsers));
	}

	/**
	 * @return zaznaczona wartosc na liscie
	 */
	public String getSelectedUsers() {
		return (String) listAllUsers.getSelectedValue();
	}

	/**
	 * Zwraca liste uzytkownikow ktorzy sa na liscie oprocz uzytkownika ktory
	 * aktualnie jest zalogowany w oknie
	 * 
	 * @return selections lista uzytkownikow zawartych w listAllUsers
	 */
	public String[] getListContent() {
		ListModel model = listAllUsers.getModel();
		String[] selections = new String[model.getSize()];
		String userNameCurrent;

		for (int i = 0; i < model.getSize(); i++) {
			userNameCurrent = (String) model.getElementAt(i);
			if (userNameCurrent.equals(ChatClientGUI.getUserName()) == true) {
				continue;
			}
			selections[i] = userNameCurrent;
		}
		return selections;
	}

	/**
	 * Zwraca cala zawartosc listy uzytkownikow
	 * 
	 * @return contentList lista uzytkownikow
	 */
	private ArrayList<String> getContentList() {
		ListModel model = listAllUsers.getModel();
		ArrayList<String> contentList = new ArrayList<>();
		String userNameCurrent;

		for (int i = 0; i < model.getSize(); i++) {
			userNameCurrent = (String) model.getElementAt(i);
			contentList.add(userNameCurrent);
		}
		return contentList;
	}

	/**
	 * Generuje polaczenie kazdego uzytkownika z listOnline ze statusem: online
	 * jesli uzytkownik jest polaczony, offline w przeciwnym przypadku
	 * 
	 * @param currentConnectNameUsers
	 *            nazwy uzytkownika ktorzy sa aktualnie polaczeni
	 * @return userWithStatus mape wszystkich uzytkownikow w liscie ze statusem
	 *         online lub offline
	 */
	private Map<String, String> setIcon(String[] currentConnectNameUsers) {
		Map<String, String> userWithStatus = new HashMap<>();

		ArrayList<String> connectUsers = new ArrayList<>();
		for (String s : currentConnectNameUsers) {
			connectUsers.add(s);
		}

		ArrayList<String> allUsers = getContentList();

		for (String name : allUsers) {
			if (connectUsers.contains(name) == true) {
				userWithStatus.put(name, "Online");
			} else {
				userWithStatus.put(name, "Offline");
			}
		}
		return userWithStatus;
	}

	/**
	 * Ustawia ikony online/ offline przy nazwa uzytkownikow w liscie
	 * 
	 * @author N.Materek
	 * @see ListOnlineGUI
	 */
	private class StatusListRendered extends DefaultListCellRenderer {

		Font font = new Font("Tahoma", 0, 14);

		/**
		 * Ustawia ikonki statusu przy nazwach uzytkownikow
		 * 
		 * @param list
		 *            aktualna lista uzytkownika
		 * @param value
		 *            online lub offline
		 * 
		 */
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {

			JLabel label = (JLabel) super.getListCellRendererComponent(list,
					value, index, isSelected, cellHasFocus);
			label.setIcon(imageMap.get((String) value));
			label.setHorizontalTextPosition(JLabel.RIGHT);
			label.setFont(font);
			return label;
		}
	}

	/**
	 * Generuje mape ktorej kluczem jest nazwa uzytkownika z wartoscia
	 * odpowiednia ikona statusu, jesli uzytkownik na mapie podanej jako
	 * parametr jest zwiazany z wartoscie Online otrzymuje odpowiednia zielona
	 * ikone, w przeciwnym razie otrzymuje czerwona ikone
	 * 
	 * @param mapUsers
	 *            mapa uzytkownikow z wartoscia online/ofline i kluczem ktory
	 *            jest nazwa uzytkownika
	 * @return map mapa nazw uzytkownika polaczonych z odpowiednia ikona
	 */
	private Map<String, ImageIcon> createImageMap(Map<String, String> mapUsers) {
		Map<String, ImageIcon> map = new HashMap<>();
		for (Map.Entry<String, String> entry : mapUsers.entrySet()) {
			if (entry.getValue().equals("Online") == true) {
				map.put(entry.getKey(), getSuitableSizeIcon(new ImageIcon(
						"src/main/resources/pl/edu/agh/kis/gui/online.png")));
			} else {
				map.put(entry.getKey(), getSuitableSizeIcon(new ImageIcon(
						"src/main/resources/pl/edu/agh/kis/gui/offline.png")));
			}
		}
		return map;
	}

	/**
	 * Zwraca ikonke o odpowiednim rozmiarze
	 * 
	 * @param imageIcon
	 *            ikonka do modyfikowania
	 * @throws Exception
	 * @return przeskalowana ikona
	 */
	private ImageIcon getSuitableSizeIcon(ImageIcon imageIcon) {
		Image image = imageIcon.getImage();
		Image newimg = image.getScaledInstance(24, 24,
				java.awt.Image.SCALE_SMOOTH);
		imageIcon = new ImageIcon(newimg);
		return (ImageIcon) imageIcon;
	}

}