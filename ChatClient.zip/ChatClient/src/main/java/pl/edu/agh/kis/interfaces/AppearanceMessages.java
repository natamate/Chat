package main.java.pl.edu.agh.kis.interfaces;

/**
 * Interfejs odpowiadajacy za wyslanie odpowiedniego komunikatu o wiadomosci
 * 
 * @author N.Materek
 * 
 */
public interface AppearanceMessages {
	/**
	 * Obsluguje akcje wyslania wiadomosci, ustawia wyglad wysylanej wiadomosci
	 * 
	 * @param nameSender
	 *            nazwa uzytkownika wysylajacego
	 * @param nameReceiver
	 *            nazwa odbiorcy
	 * @param content
	 *            tresc wiadomosci
	 */
	void sendMessage(String nameSender, String nameReceiver, String content);
}
