package main.java.pl.edu.agh.kis.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.*;
import java.util.*;

import javax.swing.JOptionPane;
import javax.swing.ListModel;

import com.sun.corba.se.impl.naming.pcosnaming.NameServer;

import main.java.pl.edu.agh.kis.gui.*;
import main.java.pl.edu.agh.kis.interfaces.AppearanceMessages;
import main.java.pl.edu.agh.kis.interfaces.Client;
import main.java.pl.edu.agh.kis.interfaces.SupportMessages;

/**
 * Klasa udostepnia zbior metod pozwalajacych na wysylanie od uzytkownika
 * informacji o zmianie stanu klienta.
 * 
 * @see Client
 * @author N.Materek
 * 
 */
public class ChatClient implements Runnable, Client {

	private Socket socket;
	private Scanner input;
	private Scanner send = new Scanner(System.in);
	private PrintWriter out;
	private AppearanceMessages invitation = new InviteGUI();
	private AppearanceMessages privateMessage = new GetPrivateMessageGUI();
	private SupportMessages message = new DefinitionNews();
	private final static String[] commandArray = { "...", "...", "...",
			"#@$!INFROOM#@!$", "#@$!SENDINVITE#", "#@$!PRIVMES#@!$",
			"#@$!DISCONNECT#", "#@$!MESSAGE@#$!", "#@$!SHUTDOWN#@!",
			"#@$!CHECKROOM#@", "#@$!THROWING#@!" };

	public ChatClient(Socket socket) {
		this.socket = socket;
	}

	/**
	 * Zwraca socket uzytkownika
	 * 
	 * @return socket
	 */
	public Socket getSocket() {
		return socket;
	}

	public void run() {
		try {
			try {
				input = new Scanner(socket.getInputStream());
				out = new PrintWriter(socket.getOutputStream());
				out.flush();
				checkStream();

			} finally {
				socket.close();
			}
		} catch (Exception e) {
			System.err.println(e);
			e.printStackTrace();
		}
	}

	/**
	 * wysyla informacje do polaczonych uzytkownikow o wylogowaniu sie
	 * uzytkownika, zamyka socket i okno uzytkownika
	 * 
	 * @throws IOException
	 *             gdy wystapi problem z wyslaniem wiadomosci o wylogowaniu
	 */
	public void disconnect() throws IOException {
		//out.println(ChatClientGUI.getUserName() + " has disconnected");
		out.println(commandArray[6] + ChatClientGUI.getUserName());
		//System.out.println(commandArray[6] + ChatClientGUI.getUserName());
		out.flush();
		socket.close();
		JOptionPane.showMessageDialog(null, "You disconnected");
		System.exit(0);
	}

	public void disconnectAnonymous() throws IOException {
		socket.close();
		JOptionPane.showMessageDialog(null, "Correct your data");
		System.exit(0);
	}

	/**
	 * Wysyla informacje do serwera o koniecznosci wylogowania wszystkich
	 * uzytkownikow
	 * 
	 * @throws IOException
	 *             gdy wystapi problem z wyslaniem wiadomosci o wylogowaniu
	 */
	public void disconnectAll() throws IOException {
		out.println(commandArray[8] + socket.getLocalPort() + ", ");
		out.flush();
	}

	private void checkStream() {
		while (true) {
			receive();
		}
	}

	private Map<String, Integer> convertToRightData(String[] data) {
		Map<String, Integer> usersMap = new HashMap<String, Integer>();
		for (String s : data) {
			if (usersMap.containsKey(s)) {
				usersMap.remove(s);
				usersMap.put(s, 2);
			} else {
				usersMap.put(s, 1);
			}
		}
		return usersMap;
	}

	/**
	 * Aktualizuje wyswietlana liste obecnie dostepnych pokoi w GUI oraz
	 * uzytkownikow dostepnych w tym samym pokoju
	 * 
	 * @param listCurrentRooms
	 *            lista Obecnie dostepnych pokoi
	 */
	private void setInfoAboutCurrentRooms(String[] listCurrentRooms) {

		Map<String, String> userWithRooms = new HashMap<String, String>();
		ArrayList<String> listAllRooms = new ArrayList<>();

		for (String s : listCurrentRooms) {
			String[] tmp = s.split(": ");
			userWithRooms.put(tmp[0], tmp[1]);
			if (tmp[2].equals("0") == true
					&& listAllRooms.contains(tmp[1]) == false) {
				listAllRooms.add(tmp[1]);
			}
		}

		String[] allRooms = new String[listAllRooms.size()];
		int counter = 0;
		for (String s : listAllRooms) {
			allRooms[counter] = s;
			counter++;
		}
		ChatClientGUI.setListAvailableRoom(allRooms);
		
		ChatClientGUI.setLabelExistInRoomAsBox(userWithRooms);
	}

	/**
	 * Aktualizuje wyswietlana liste obecnie dostepnch uzytkownikow
	 * 
	 * @param usersMap
	 *            mapa wszystkich uzytkownikow klucz to nazwa uzytkownika a
	 *            wartosc to liczba wskazujaca na to czy uzytkownik jest
	 *            zalogowany czy nie 1 - polaczony 2 - niepolaczony
	 */
	private void setInfoAboutCurrentOnlineUsers(Map<String, Integer> usersMap) {
		Map<String, String> allUsers = new HashMap<String, String>();
		ArrayList<String> connectUsers = new ArrayList<String>();
		for (Map.Entry<String, Integer> entry : usersMap.entrySet()) {
			if (entry.getValue() == 1) {
				allUsers.put(entry.getKey(), "doesn't matter");
			} else {
				allUsers.put(entry.getKey(), "doesn't matter");
				connectUsers.add(entry.getKey());
			}
		}

		String[] connect = new String[connectUsers.size()];
		int counter = 0;
		for (String s : connectUsers) {
			connect[counter] = s;
			counter++;
		}
		ChatClientGUI.setListOnlineUsers(connect, allUsers);
	}

	/**
	 * Sprawdza czy input zawiera charakterystyczny ciag znakow, aby wykonac
	 * odpowiednia operacje, jesli input nie zawiera zadnego wyspecjalizowanego
	 * ciagu znakow z commandArray ustawia wiadomosc w polu czatu
	 */
	private void receive() {
		if (input.hasNext() == true) {

			String currentMessage = input.nextLine();
		//	System.out.println("ChatClient msg: " + currentMessage);
			SupportMessages msg;
			msg = message.makeDefinitionNews(currentMessage);

			switch (msg.getTypeMessage()) {
			case 0:
				ChatClientGUI.addToAreaTextConversation(currentMessage + "\n");
				break;
			case 1:
				setInfoAboutCurrentOnlineUsers(convertToRightData(msg
						.getMessage()));
				break;
			case 2:
				setInfoAboutCurrentRooms(msg.getMessage());
				break;
			case 3:
				String[] currentInvite = msg.getMessage();
				invitation.sendMessage(currentInvite[0], currentInvite[1],
						currentInvite[2] + ". " + currentInvite[3]);
				break;
			case 7:
				try {
					disconnect();
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
			case 8:
				String[] nameUsers = msg.getMessage();
				privateMessage.sendMessage(nameUsers[0], nameUsers[1],
						nameUsers[2]);
				break;
			case 11:
				try {
					disconnectAnonymous();
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
			default:
				break;
			}

		}

	}

	/**
	 * Wysyla wiadomosc, czysci pole do wpisywania wiadomosci
	 * 
	 * @param message
	 *            tresc wiadomosci
	 */
	public void sendMessage(String message) {
		out.println(ChatClientGUI.getUserName() + ": " + message);
		out.flush();
		ChatClientGUI.setTextFieldMessage("");
	}

	/**
	 * Wysyla wiadomosc o tym ze uzytkownikow zmienil pokoj
	 * 
	 * @param roomName
	 *            nowa nazwa pokoju
	 * @param available
	 *            nowa dostepnosc pokoju
	 * @param username
	 *            nazwa uzytkownika ktory zmienil pokoj
	 */
	public void sendInfoAboutRoom(String roomName, int available,
			String username) {

		//System.out.println(username + ", " + roomName + ", " + available);
		if (out == null) {
			try {
				out = new PrintWriter(socket.getOutputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			out.println(commandArray[3] + username + ", " + roomName + ", "
						+ available);
			out.flush();
		}
	}

	/**
	 * wysyla zaproszenie do pokoju
	 * 
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal zaproszenie
	 * @param nameReceiver
	 *            nazwa uzytkownika ktory ma otrzymac zaproszenie
	 * @param nameChatRoom
	 *            nazwa pokoju do ktorego zostal zaproszony uzytkownik
	 */
	public void sendInvite(String nameSender, String nameReceiver,
			String nameChatRoom) {
		out.println(commandArray[4] + nameSender + ", " + nameReceiver + ", "
				+ nameChatRoom);
		out.flush();
	}

	/**
	 * Wysyla wiadomosc prywatna
	 * 
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 * @param nameReceiver
	 *            nazwa uzytkownika ktory ma otrzymac wiadomosc
	 * @param message
	 *            wlasciwa tresc wiadomosci
	 */

	public void sendPrivateMessage(String nameSender, String nameReceiver,
			String message) {
		out.println(commandArray[5] + nameSender + ", " + nameReceiver + ", "
				+ message);
		out.flush();
	}

	/**
	 * Wysyla zapytanie zeby sprawdzic czy nazwa pokoju jest zajeta
	 * 
	 * @param roomToCheck
	 *            pokoj dla ktorego bedzie sprawdzana dostepnosc nazwy
	 * @param userName
	 *            nazwa uzytkownika ktory chce zalozyc pokoj
	 */
	public void sendQuestionAboutAvailableRoomName(ChatRoom roomToCheck,
			String userName) {
		out.println(commandArray[9] + userName + ", "
				+ roomToCheck.getRoomName() + ", " + roomToCheck.getAvailable());
		out.flush();
	}
}