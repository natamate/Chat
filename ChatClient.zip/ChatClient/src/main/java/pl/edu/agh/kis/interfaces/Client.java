package main.java.pl.edu.agh.kis.interfaces;

import java.io.IOException;
import java.net.Socket;

import main.java.pl.edu.agh.kis.core.ChatRoom;

/**
 * Interfejs udostepniajacy zbior metod pozwalajacy na przesylanie informacji o
 * zmianie stanu klienta lub o akcji klienta
 * 
 * @author N.Materek
 * 
 */
public interface Client {
	/**
	 * Wysyla wiadomosc, czysci pole do wpisywania wiadomosci
	 * 
	 * @param message
	 *            tresc wiadomosci
	 */
	void sendMessage(String message);

	/**
	 * wysyla informacje do polaczonych uzytkownikow o wylogowaniu sie
	 * uzytkownika, zamyka socket i okno uzytkownika
	 * 
	 * @throws IOException
	 *             gdy wystapi problem z wyslaniem wiadomosci o wylogowaniu
	 */
	void disconnect() throws IOException;

	/**
	 * Wysyla informacje do serwera o koniecznosci wylogowania wszystkich
	 * uzytkownikow
	 * 
	 * @throws IOException
	 *             gdy wystapi problem z wyslaniem wiadomosci o wylogowaniu
	 */
	void disconnectAll() throws IOException;

	/**
	 * Zwraca socket uzytkownika
	 * 
	 * @return socket
	 */
	Socket getSocket();

	/**
	 * Wysyla wiadomosc o tym ze uzytkownikow zmienil pokoj
	 * 
	 * @param roomName
	 *            nowa nazwa pokoju
	 * @param available
	 *            nowa dostepnosc pokoju
	 * @param userName
	 *            nazwa uzytkownika ktory zmienil pokoj
	 */
	void sendInfoAboutRoom(String roomName, int available, String userName);

	/**
	 * wysyla zaproszenie do pokoju
	 * 
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal zaproszenie
	 * @param nameReceiver
	 *            nazwa uzytkownika ktory ma otrzymac zaproszenie
	 * @param nameChatRoom
	 *            nazwa pokoju do ktorego zostal zaproszony uzytkownik
	 */
	void sendInvite(String nameSender, String nameReceiver, String nameChatRoom);

	/**
	 * Wysyla wiadomosc prywatna
	 * 
	 * @param nameSender
	 *            nazwa uzytkownika ktory wyslal wiadomosc
	 * 
	 * @param nameReceiver
	 *            nazwa uzytkownika ktory ma otrzymac wiadomosc
	 * @param message
	 *            wlasciwa tresc wiadomosci
	 */
	void sendPrivateMessage(String nameSender, String nameReceiver,
			String message);

	/**
	 * Wysyla zapytanie zeby sprawdzic czy nazwa pokoju jest zajeta
	 * 
	 * @param newChatRoom
	 *            pokoj dla ktorego bedzie sprawdzana dostepnosc nazwy
	 * @param userName
	 *            nazwa uzytkownika ktory chce zalozyc pokoj
	 */
	void sendQuestionAboutAvailableRoomName(ChatRoom newChatRoom,
			String userName);
}
