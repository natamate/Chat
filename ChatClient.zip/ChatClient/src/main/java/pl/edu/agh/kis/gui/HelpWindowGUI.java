package main.java.pl.edu.agh.kis.gui;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.*;

import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.File;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Generuje akcje przycisku Help
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class HelpWindowGUI implements ButtonAction {
	private static JFrame frame;
	private static JPanel panel;
	private static JTextArea text;
	private static JButton buttonOk;
	private static JScrollPane scrollPanel;

	private static String help() {
		try {
			File file = new File(
					"src/main/resources/pl/edu/agh/kis/gui/help.txt");
			StringBuilder fileContents = new StringBuilder((int) file.length());
			Scanner scanner = new Scanner(file);
			String lineSeparator = System.getProperty("line.separator");
			while (scanner.hasNextLine()) {
				fileContents.append(scanner.nextLine() + lineSeparator);
			}
			scanner.close();
			return fileContents.toString();
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
	}

	private static void buildMainWindow() {
		frame = new JFrame();
		frame.setTitle("Chat Client Help");
		frame.setSize(300, 300);
		frame.setLocation(300, 300);

		panel = new JPanel();
		panel.setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4,
				new java.awt.Color(255, 255, 255)));
		panel.setLayout(null);
		frame.getContentPane().setLayout(null);
		buttonOk = new JButton("OK");

		text = new JTextArea();
		text.setLineWrap(true);
		text.setColumns(20);
		text.setRows(5);
		text.setWrapStyleWord(true);

		text.setText(help());
		text.setEditable(false);
		text.setVisible(true);

		scrollPanel = new JScrollPane(text);
		scrollPanel
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPanel
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPanel.setBounds(10, 10, 275, 220);

		frame.add(scrollPanel);

		buttonOk.setBounds(100, 240, 100, 30);
		buttonOk.setBackground(new java.awt.Color(0, 0, 255));
		buttonOk.setForeground(new java.awt.Color(255, 255, 255));
		buttonOk.setEnabled(true);
		buttonOk.setVisible(true);

		frame.add(buttonOk);
		frame.setVisible(true);
	}

	/**
	 * Generuje akcje przycisku help
	 */
	public void actionButton() {
		buildMainWindow();
		buttonAction();
	}

	private static void buttonAction() {
		buttonOk.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent event) {
				frame.setVisible(false);
			}
		});
	}
}
