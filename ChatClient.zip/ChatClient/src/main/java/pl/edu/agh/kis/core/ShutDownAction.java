package main.java.pl.edu.agh.kis.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import main.java.pl.edu.agh.kis.gui.ChatClientGUI;
import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

public class ShutDownAction implements ButtonAction {

	@Override
	public void actionButton() {
		try {
			ChatClientGUI.getCurrentChatClient().disconnectAll();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
