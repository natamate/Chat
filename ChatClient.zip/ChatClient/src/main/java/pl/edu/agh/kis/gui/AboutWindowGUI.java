package main.java.pl.edu.agh.kis.gui;

import javax.swing.JOptionPane;

import main.java.pl.edu.agh.kis.interfaces.ButtonAction;

/**
 * Generuje akcje przycisku About
 * 
 * @author N.Materek
 * @see ChatClientGUI
 * @see ButtonAction
 */
public class AboutWindowGUI implements ButtonAction {
	public void actionButton() {
		StringBuilder sb = new StringBuilder();
		sb.append("Multi Client Chat Server v 1.3");
		sb.append("\n");
		sb.append("Author: N.Materek");
		sb.append("\n");
		sb.append("01.2017");
		JOptionPane.showMessageDialog(null, sb.toString());
	}

}
