package main.java.pl.edu.agh.kis.core;

import java.util.ArrayList;

import javax.smartcardio.CommandAPDU;

import main.java.pl.edu.agh.kis.interfaces.Command;
import main.java.pl.edu.agh.kis.interfaces.SupportMessages;

public class DefinitionNews implements SupportMessages {
	/**
	 * Wlasciwa tresc wiadomosci
	 */
	private String[] message;
	/**
	 * Zmienna okreslajaca typ wiadomosci: wiadomosc standardowa, zaproszenie,
	 * wiadomosc prywatna
	 */
	private int typeMessage = 0;

	public DefinitionNews() {

	}

	private DefinitionNews(int typeMessage, String[] message) {
		this.typeMessage = typeMessage;
		this.message = message;
	}

	/**
	 * Zwraca wiadomosc z okreslonym typem patrz Command MESSAGE(0), ADDUSER(1),
	 * ADDROOM(2), INVITES(3), INFROOM(4), SENDINVITE(5), PRIVMES( 6),
	 * DISCONNECT(7), DELIVERPRIV(8);
	 */
	public DefinitionNews makeDefinitionNews(String inputMessage) {

		if (inputMessage.contains("#@$!") == false) {
			String[] message = { inputMessage };
			return new DefinitionNews(0, message);
		}
		String tmp = inputMessage.substring(15);
		String[] messageData = tmp.split(", ");

		return new DefinitionNews(getTypeFromCommand(inputMessage), messageData);
	}

	private int getTypeFromCommand(String inputMessages) {
		if (inputMessages.contains("ADDUSER") == true) {
			return Command.ADDUSER.getValue();
		} else if (inputMessages.contains("ADDROOM") == true) {
			return Command.ADDROOM.getValue();
		} else if (inputMessages.contains("INVITES") == true) {
			return Command.INVITES.getValue();
		} else if (inputMessages.contains("INFROOM") == true) {
			return Command.INFROOM.getValue();
		} else if (inputMessages.contains("SENDINVITE") == true) {
			return Command.SENDINVITE.getValue();
		} else if (inputMessages.contains("PRIVMES") == true) {
			return Command.PRIVMES.getValue();
		} else if (inputMessages.contains("DISCONNECT") == true) {
			return Command.DISCONNECT.getValue();
		} else if (inputMessages.contains("MESSAGE") == true) {
			return Command.DELIVERPRIV.getValue();
		}else if(inputMessages.contains("SHUTDOWN") == true){
			return Command.SHUTDOWN.getValue();
		}else if(inputMessages.contains("CHECKROOM") == true){
			return Command.CHECKROOM.getValue();
		} else if(inputMessages.contains("THROWING") == true){
			return Command.THROWING.getValue();
		} else {
			return Command.MESSAGE.getValue();
		}
	}

	/**
	 * Zwraca tresc wiadomosci
	 * 
	 * @return wlasciwa tresc
	 */
	public String[] getMessage() {
		return message;
	}

	/**
	 * Zwraca typ wiadomosci
	 * 
	 * @return int typ
	 */
	public int getTypeMessage() {
		return typeMessage;
	}
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("Type: " + typeMessage + "\n");
		for (String s : message){
			sb.append(s + " ");
		}
		return sb.toString();
	}
}
