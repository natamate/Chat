Projekt czat serwer realizujacy zadanie komunikacji publicznej i prywatnej miedzy klientami.
Uruchom ChatServer.
Uruchom ChatClientGUI z klienta czatu (ChatClient). Kliknij connect i wpisz nazwe hosta, swoja nazwe uzytkownika oraz haslo. Nie podanie hosta powoduje przyjecie za host "localhost".

Komunikat:
"Server not responding" serwer nie jest wlaczony.
"Unknown host" podany host jest bledny.
"Incorrect password" podane haslo jest nieprawidlowe.

Jesli logujesz sie po raz pierwszy twoje haslo i nazwa uzytkownika zostana zapisane i beda weryfikowac Cie przy nastepnym polaczeniu.

Jesli potzrebujesz wiecej informacji kliknij help po wlaczeniu klienta czatu
